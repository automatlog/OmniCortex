import asyncio
import base64
import json
import logging
import logging.handlers
import os
import wave
from contextlib import suppress
from datetime import datetime
from typing import Any, Optional

import websockets
from websockets.exceptions import ConnectionClosed


# ─────────────────────────────────────────────
#  LOGGING  —  console + two rotating log files
#
#  Files written to LOG_DIR (default: ./logs/):
#    bridge_YYYYMMDD.log         ← all events (DEBUG+), rotates daily, 7 days backup
#    audio_events_YYYYMMDD.log   ← ONLY audio/TTS/STT events for easy analysis
#
#  Override:
#    LOG_DIR=/var/log/ai_bridge python3 fast_ai_bridge.py
# ─────────────────────────────────────────────
LOG_LEVEL = os.getenv("LOG_LEVEL", "DEBUG").upper()
LOG_DIR   = os.getenv("LOG_DIR",   "./logs").strip()

os.makedirs(LOG_DIR, exist_ok=True)

_LOG_FMT  = "%(asctime)s  %(levelname)-8s  %(message)s"
_DATE_FMT = "%Y-%m-%d %H:%M:%S"
_today    = datetime.now().strftime("%Y%m%d")
_formatter = logging.Formatter(_LOG_FMT, datefmt=_DATE_FMT)

# ── 1. Console handler ────────────────────────────────────────
_console_hdl = logging.StreamHandler()
_console_hdl.setLevel(LOG_LEVEL)
_console_hdl.setFormatter(_formatter)

# ── 2. Main log file  (ALL events — DEBUG+) ───────────────────
#    bridge_20250320.log  →  rotates at midnight, keeps 7 days
_main_log_path = os.path.join(LOG_DIR, f"bridge_{_today}.log")
_main_hdl = logging.handlers.TimedRotatingFileHandler(
    _main_log_path, when="midnight", backupCount=7, encoding="utf-8",
)
_main_hdl.setLevel(LOG_LEVEL)
_main_hdl.setFormatter(_formatter)
_main_hdl.suffix = "%Y%m%d"

# ── 3. Audio events log file  (ONLY audio/TTS/STT lines) ─────
#    audio_events_20250320.log  →  rotates at midnight, keeps 7 days
_audio_log_path = os.path.join(LOG_DIR, f"audio_events_{_today}.log")
_audio_hdl = logging.handlers.TimedRotatingFileHandler(
    _audio_log_path, when="midnight", backupCount=7, encoding="utf-8",
)
_audio_hdl.setLevel(logging.DEBUG)
_audio_hdl.setFormatter(_formatter)
_audio_hdl.suffix = "%Y%m%d"

class _AudioFilter(logging.Filter):
    """Allow only log lines that are related to audio / TTS / STT events."""
    _KEYWORDS = (
        "[EL-FRAME",   # ElevenLabs per-chunk frames
        "[EL-DONE",    # ElevenLabs utterance complete
        "[EL-SUMMARY", # end-of-call TTS stats
        "[FS-FRAME",   # caller PCM frames received from FreeSWITCH
        "[tts]",       # WAV save messages
        "TTS playback",
        "STT:",
        "tts_audio",
        "tts_done",
        "ESL play",
        "ESL-BUFFER",
        "bytes TTS",
        "utterance",
        "-> FS: sent",
    )
    def filter(self, record: logging.LogRecord) -> bool:
        return any(kw in record.getMessage() for kw in self._KEYWORDS)

_audio_hdl.addFilter(_AudioFilter())

# ── Wire everything up ────────────────────────────────────────
logging.basicConfig(level=LOG_LEVEL, handlers=[
    _console_hdl,
    _main_hdl,
    _audio_hdl,
])
logger = logging.getLogger("fast_ai_bridge")


# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
FS_IP                    = os.getenv("FS_IP",                    "0.0.0.0").strip()
FS_PORT                  = int(os.getenv("FS_PORT",              "8001"))
AI_AGENT_WS_URL          = os.getenv("AI_AGENT_WS_URL",         "ws://192.168.29.146:14496/bridge").strip()
AI_AGENT_CONNECT_TIMEOUT = float(os.getenv("AI_AGENT_CONNECT_TIMEOUT", "10"))
TRIGGER_WELCOME          = os.getenv("TRIGGER_WELCOME",          "true").lower() == "true"

# Credentials forwarded to ai_agent.py via "control" message on call start.
# These match API_BEARER_TOKEN / API_AGENT_ID used in ai_agent.py.
# If FreeSWITCH also sends them via a text control frame, those override these.
OMNI_BEARER              = os.getenv("OMNI_BEARER",              os.getenv("API_BEARER_TOKEN", "")).strip()
OMNI_USER_ID             = os.getenv("OMNI_USER_ID",             "voice_user").strip()
OMNI_AGENT_ID            = os.getenv("OMNI_AGENT_ID",            os.getenv("API_AGENT_ID",     "")).strip()

# TTS playback via ESL uuid_broadcast (mod_audio_stream is send-only, confirmed by testing)
USE_ESL_PLAYBACK         = os.getenv("USE_ESL_PLAYBACK",         "true").lower() == "true"
FS_ESL_HOST              = os.getenv("FS_ESL_HOST",              "127.0.0.1").strip()
FS_ESL_PORT              = int(os.getenv("FS_ESL_PORT",          "8021"))
FS_ESL_PASSWORD          = os.getenv("FS_ESL_PASSWORD",          "ClueCon").strip()
TTS_WAV_DIR              = os.getenv("TTS_WAV_DIR",              "/tmp").strip()


# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────
async def _safe_send_text(ws, payload: dict[str, Any]) -> None:
    """Send JSON without raising if socket is closed."""
    try:
        await ws.send(json.dumps(payload))
    except Exception:
        pass


async def _safe_send_bytes(ws, data: bytes) -> None:
    """Send raw bytes without raising if socket is closed."""
    try:
        await ws.send(data)
    except Exception:
        pass


def _bytes_to_kb(b: int) -> str:
    return f"{b / 1024:.2f} KB"


# ─────────────────────────────────────────────
#  ESL HELPER  (only used when USE_ESL_PLAYBACK=true)
# ─────────────────────────────────────────────
async def _esl_command(cmd: str) -> str:
    """
    Send a single API command to FreeSWITCH via ESL inbound socket.
    Returns response text, or empty string on failure.
    """
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(FS_ESL_HOST, FS_ESL_PORT),
            timeout=5,
        )
        # Read initial "Content-Type: auth/request"
        await asyncio.wait_for(reader.readuntil(b"\n\n"), timeout=5)

        # Authenticate
        writer.write(f"auth {FS_ESL_PASSWORD}\n\n".encode())
        await writer.drain()
        auth_resp = await asyncio.wait_for(reader.readuntil(b"\n\n"), timeout=5)
        if b"+OK" not in auth_resp and b"accepted" not in auth_resp:
            logger.error("[esl] Auth failed: %s", auth_resp.decode(errors="ignore").strip())
            writer.close()
            return ""

        # Send API command
        writer.write(f"api {cmd}\n\n".encode())
        await writer.drain()

        response_data = await asyncio.wait_for(reader.read(8192), timeout=10)
        writer.close()

        resp_text = response_data.decode(errors="ignore")
        logger.info("[esl] '%s' -> %s", cmd[:80], resp_text.strip()[:120])
        return resp_text
    except Exception as exc:
        logger.error("[esl] Command '%s' failed: %s", cmd[:80], exc)
        return ""


# ─────────────────────────────────────────────
#  WAV HELPER  (only used when USE_ESL_PLAYBACK=true)
# ─────────────────────────────────────────────
def _save_pcm_as_wav(pcm_bytes: bytes, filepath: str, sample_rate: int = 8000) -> None:
    """Save raw L16 PCM bytes as a proper WAV file."""
    with wave.open(filepath, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)          # 16-bit
        wf.setframerate(sample_rate)
        wf.writeframes(pcm_bytes)
    duration_s = len(pcm_bytes) / (sample_rate * 2)
    logger.info(
        "[tts] WAV saved: %s  (%s PCM, %.2fs audio)",
        filepath, _bytes_to_kb(len(pcm_bytes)), duration_s,
    )


# ─────────────────────────────────────────────
#  ELEVENLABS FRAME MAPPER
#
#  Tracks every TTS chunk for visibility in logs.
#  Log format:
#    [EL-FRAME ] #0001 | utterance=1 | frame_in_utt=001 | size=0.25 KB | total_so_far=0.25 KB
#    [EL-DONE  ] Utterance #1 complete - 24 frames | 6.00 KB audio
#    [EL-SUMMARY] Call ended - 48 total frames | 2 utterances | 12.00 KB total TTS audio
# ─────────────────────────────────────────────
class ElevenLabsFrameMapper:

    def __init__(self):
        self.frame_count      = 0
        self.total_bytes      = 0
        self.utterance_num    = 0
        self.utterance_frames = 0
        self.utterance_bytes  = 0

    def on_tts_audio(self, pcm_bytes: bytes) -> None:
        """Log every single TTS audio frame arriving from ElevenLabs."""
        self.frame_count      += 1
        self.total_bytes      += len(pcm_bytes)
        self.utterance_frames += 1
        self.utterance_bytes  += len(pcm_bytes)

        logger.debug(
            "[EL-FRAME ] #%04d | utterance=%d | frame_in_utt=%03d | "
            "size=%-10s | total_so_far=%s",
            self.frame_count,
            self.utterance_num + 1,
            self.utterance_frames,
            _bytes_to_kb(len(pcm_bytes)),
            _bytes_to_kb(self.total_bytes),
        )

    def on_tts_done(self) -> None:
        """Log utterance summary when AI finishes speaking."""
        self.utterance_num += 1
        logger.info(
            "[EL-DONE  ] Utterance #%d complete - %d frames | %s audio",
            self.utterance_num,
            self.utterance_frames,
            _bytes_to_kb(self.utterance_bytes),
        )
        self.utterance_frames = 0
        self.utterance_bytes  = 0

    def summary(self) -> None:
        """Log full-call ElevenLabs stats at end of call."""
        logger.info(
            "[EL-SUMMARY] %d total ElevenLabs frames | %d utterances | %s total TTS audio",
            self.frame_count,
            self.utterance_num,
            _bytes_to_kb(self.total_bytes),
        )


# ─────────────────────────────────────────────
#  BRIDGE HANDLER
# ─────────────────────────────────────────────
async def bridge_handler(fs_ws, path: Optional[str] = None):
    logger.info("[bridge] ============== NEW CALL ==============")

    agent_ws         = None
    hangup_requested = False
    el_mapper        = ElevenLabsFrameMapper()

    # Try to extract UUID from WebSocket path (e.g. /5a677045-... if dialplan sends it)
    call_uuid = ""
    ws_path = path or ""
    if not ws_path and hasattr(fs_ws, "path"):
        ws_path = getattr(fs_ws, "path", "") or ""
    if not ws_path and hasattr(fs_ws, "request"):
        ws_path = getattr(fs_ws.request, "path", "") or ""
    ws_path = ws_path.strip("/")
    # UUID format: 8-4-4-4-12 hex chars
    if len(ws_path) >= 36 and ws_path.count("-") == 4:
        call_uuid = ws_path
        logger.info("[bridge] UUID from WebSocket path: %s", call_uuid)
    else:
        logger.info("[bridge] No UUID in path ('%s') - will extract from metadata", ws_path)

    try:
        # -- 1. Connect to AI Agent -------------------------------------------
        try:
            agent_ws = await websockets.connect(
                AI_AGENT_WS_URL,
                open_timeout=AI_AGENT_CONNECT_TIMEOUT,
                ping_interval=None,         # no keepalive pings - better for real-time audio
                max_size=8 * 1024 * 1024,
            )
            logger.info("[bridge] Connected to AI agent -> %s", AI_AGENT_WS_URL)
        except (ConnectionRefusedError, OSError) as exc:
            logger.error("[bridge] Cannot reach AI agent at %s - %s", AI_AGENT_WS_URL, exc)
            await _safe_send_text(fs_ws, {
                "type":   "error",
                "detail": f"AI agent unreachable: {AI_AGENT_WS_URL}",
            })
            return

        # -- 2. call_start -----------------------------------------------------
        await agent_ws.send(json.dumps({"type": "call_start"}))
        logger.info("[bridge] Sent -> call_start")

        # -- 2b. Send initial control with credentials from env vars -----------
        # ai_agent.py needs omni_bearer + agent_id to call api.py /query (RAG).
        # FreeSWITCH may also send these later via a text control frame (those
        # will override). Sending upfront ensures agent is ready even if FS
        # never sends a control frame.
        if OMNI_BEARER or OMNI_AGENT_ID:
            await agent_ws.send(json.dumps({
                "type":          "control",
                "omni_bearer":   OMNI_BEARER,
                "omni_user_id":  OMNI_USER_ID,
                "omni_agent_id": OMNI_AGENT_ID,
            }))
            logger.info(
                "[bridge] Sent -> initial control (user_id=%s agent_id=%s bearer=%s)",
                OMNI_USER_ID,
                OMNI_AGENT_ID,
                "***" if OMNI_BEARER else "(none)",
            )

        # -- 3. trigger_welcome (AI speaks first) ------------------------------
        if TRIGGER_WELCOME:
            await agent_ws.send(json.dumps({"type": "trigger_welcome"}))
            logger.info("[bridge] Sent -> trigger_welcome (AI will speak first)")
        else:
            logger.info("[bridge] TRIGGER_WELCOME=false - waiting for caller to speak")

        # -- 4. FreeSWITCH -> Agent (caller's voice) --------------------------
        async def from_freeswitch():
            """
            Receive raw PCM + metadata from FreeSWITCH.
            - Text frames  -> parse for call_uuid + control fields -> forward to agent
            - Binary frames -> base64 encode -> forward as audio to agent
            """
            nonlocal call_uuid
            fs_frame_count = 0

            async for message in fs_ws:

                # -- Text / metadata / control frame ---------------------------
                if isinstance(message, str):
                    # Log ALL text frames from FreeSWITCH for debugging
                    logger.info("[bridge] FS text frame: %s", message[:500])

                    try:
                        parsed = json.loads(message)
                        if isinstance(parsed, dict):

                            # Extract call UUID from metadata - needed for ESL playback
                            if not call_uuid:
                                uuid_val = str(
                                    parsed.get("uuid")
                                    or parsed.get("channel_uuid")
                                    or parsed.get("callId")
                                    or parsed.get("call_id")
                                    or ""
                                ).strip()
                                if uuid_val:
                                    call_uuid = uuid_val
                                    logger.info("[bridge] Call UUID from metadata: %s", call_uuid)

                            # Forward auth/control fields to agent
                            bearer   = str(parsed.get("omni_bearer")   or parsed.get("bearer")    or parsed.get("api_key")  or "").strip()
                            user_id  = str(parsed.get("omni_user_id")  or parsed.get("x_user_id") or parsed.get("user_id")  or "").strip()
                            agent_id = str(parsed.get("omni_agent_id") or parsed.get("agent_id")  or "").strip()

                            if bearer or user_id or agent_id:
                                await agent_ws.send(json.dumps({
                                    "type":          "control",
                                    "omni_bearer":   bearer,
                                    "omni_user_id":  user_id,
                                    "omni_agent_id": agent_id,
                                }))
                                logger.info("[bridge] Forwarded control frame (user_id=%s)", user_id)
                    except json.JSONDecodeError:
                        logger.warning("[bridge] Non-JSON text from FS: %s", message[:200])
                    except Exception:
                        pass
                    continue

                # -- Raw PCM binary frame --------------------------------------
                if not isinstance(message, (bytes, bytearray)):
                    continue
                audio_bytes = bytes(message)
                if not audio_bytes:
                    continue

                fs_frame_count += 1
                if fs_frame_count % 500 == 1:
                    logger.debug(
                        "[FS-FRAME ] #%04d | size=%-10s | caller -> agent",
                        fs_frame_count,
                        _bytes_to_kb(len(audio_bytes)),
                    )

                audio_b64 = base64.b64encode(audio_bytes).decode("ascii")
                await agent_ws.send(json.dumps({
                    "type":  "audio",
                    "audio": audio_b64,
                }))

            logger.info("[bridge] FreeSWITCH stream ended (caller frames: %d)", fs_frame_count)

        # -- 5. Agent -> FreeSWITCH (ElevenLabs TTS + events) -----------------
        async def from_agent():
            """
            Receive messages from ai_agent.py.

            TTS playback (default - ESL mode):
              mod_audio_stream is send-only, so we accumulate tts_audio chunks
              in a buffer. On tts_done -> save as WAV -> play via ESL uuid_broadcast.
              Requires call_uuid (from metadata or WebSocket path).
            """
            nonlocal hangup_requested

            # ESL mode: accumulate TTS chunks here
            tts_buffer = bytearray()
            tts_chunk_count = 0

            async for message in agent_ws:
                if not isinstance(message, str):
                    continue
                try:
                    data = json.loads(message)
                except json.JSONDecodeError:
                    logger.warning("[bridge] Non-JSON from agent - skipping")
                    continue

                msg_type = data.get("type", "")

                # -- ElevenLabs TTS audio chunk --------------------------------
                if msg_type == "tts_audio":
                    audio_b64 = data.get("audio", "")
                    if not audio_b64:
                        continue

                    pcm_bytes = base64.b64decode(audio_b64)
                    el_mapper.on_tts_audio(pcm_bytes)   # frame mapper always logs

                    if USE_ESL_PLAYBACK:
                        # ESL mode: buffer the chunk, play later on tts_done
                        tts_buffer.extend(pcm_bytes)
                        tts_chunk_count += 1
                    else:
                        # Direct mode: send chunk immediately to FreeSWITCH
                        await _safe_send_bytes(fs_ws, pcm_bytes)
                    continue

                # -- TTS utterance complete ------------------------------------
                if msg_type == "tts_done":
                    el_mapper.on_tts_done()

                    if USE_ESL_PLAYBACK and tts_buffer:
                        # ESL mode: save accumulated PCM as WAV and play via uuid_broadcast
                        if call_uuid:
                            wav_path = os.path.join(
                                TTS_WAV_DIR,
                                f"tts_{call_uuid}_{el_mapper.utterance_num}.wav",
                            )
                            _save_pcm_as_wav(bytes(tts_buffer), wav_path, sample_rate=8000)
                            logger.info(
                                "[bridge] ESL play: %s (%d chunks, %s)",
                                wav_path, tts_chunk_count, _bytes_to_kb(len(tts_buffer)),
                            )
                            await _esl_command(f"uuid_broadcast {call_uuid} {wav_path} aleg")
                        else:
                            logger.warning("[bridge] ESL mode: no call_uuid yet - falling back to direct send")
                            await _safe_send_bytes(fs_ws, bytes(tts_buffer))

                        tts_buffer.clear()
                        tts_chunk_count = 0
                    elif not USE_ESL_PLAYBACK:
                        logger.info("[bridge] TTS playback complete (direct mode, all chunks sent)")
                    else:
                        logger.info("[bridge] TTS done but buffer empty")
                    continue

                # -- AI text reply (log only, FS only understands audio) ------
                if msg_type == "ai_reply":
                    logger.info("[bridge] AI reply: %s", str(data.get("reply_text", ""))[:150])
                    continue

                # -- STT transcript (log only) ---------------------------------
                if msg_type == "stt_final":
                    logger.info("[bridge] STT: %s", data.get("text", ""))
                    continue

                # -- AI requested hangup ---------------------------------------
                if msg_type == "hangup":
                    logger.info("[bridge] AI requested HANGUP - closing call")
                    hangup_requested = True
                    break   # exits from_agent(); asyncio.wait cancels from_freeswitch()

                # -- Agent ready signal ----------------------------------------
                if msg_type == "ready":
                    logger.info("[bridge] Agent is ready")
                    continue

                # -- Error from agent ------------------------------------------
                if msg_type == "error":
                    logger.error("[bridge] Agent error: %s", data.get("detail", ""))
                    continue

                # -- Unknown -> ignore (FS only understands binary audio) ------
                logger.debug("[bridge] Unknown msg_type='%s' - ignoring", msg_type)

        # -- 6. Run both directions concurrently -------------------------------
        tasks = [
            asyncio.create_task(from_freeswitch(), name="from_freeswitch"),
            asyncio.create_task(from_agent(),      name="from_agent"),
        ]
        done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)

        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

        for task in done:
            exc = task.exception()
            if exc and not isinstance(exc, ConnectionClosed):
                logger.error(
                    "[bridge] Task '%s' raised: %s - %s",
                    task.get_name(), type(exc).__name__, exc,
                )

    except ConnectionClosed:
        logger.info("[bridge] Connection closed by remote side")
    except Exception as exc:
        logger.exception("[bridge] Unexpected error: %s", exc)
        await _safe_send_text(fs_ws, {"type": "error", "detail": str(exc)})

    finally:
        el_mapper.summary()     # full-call ElevenLabs stats

        # Cleanup temp WAV files if ESL mode was used
        if USE_ESL_PLAYBACK and call_uuid:
            for i in range(1, el_mapper.utterance_num + 1):
                wav_path = os.path.join(TTS_WAV_DIR, f"tts_{call_uuid}_{i}.wav")
                with suppress(Exception):
                    os.remove(wav_path)
                    logger.debug("[bridge] Removed temp WAV: %s", wav_path)

        if agent_ws and not agent_ws.closed:
            with suppress(Exception):
                await agent_ws.send(json.dumps({"type": "call_end"}))
                logger.info("[bridge] Sent -> call_end to AI agent")
            with suppress(Exception):
                await agent_ws.close()

        with suppress(Exception):
            await fs_ws.close()

        reason = "AI hangup" if hangup_requested else "caller / network"
        logger.info("[bridge] ========== CALL ENDED (%s) ==========", reason)


# ─────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────
async def main():
    server = await websockets.serve(
        bridge_handler,
        FS_IP,
        FS_PORT,
        ping_interval=None,
        max_size=8 * 1024 * 1024,
    )

    tts_mode = f"ESL uuid_broadcast ({FS_ESL_HOST}:{FS_ESL_PORT})" if USE_ESL_PLAYBACK else "Direct WebSocket stream"

    logger.info("=" * 60)
    logger.info("  fast_ai_bridge  STARTED")
    logger.info("  Listening    : %s:%s",  FS_IP, FS_PORT)
    logger.info("  AI Agent     : %s",     AI_AGENT_WS_URL)
    logger.info("  Welcome msg  : %s",     "YES - AI speaks first" if TRIGGER_WELCOME else "NO - caller speaks first")
    logger.info("  TTS mode     : %s",     tts_mode)
    logger.info("  TTS WAV dir  : %s",     TTS_WAV_DIR)
    logger.info("  Log level    : %s",     LOG_LEVEL)
    logger.info("  Main log     : %s",     _main_log_path)
    logger.info("  Audio log    : %s",     _audio_log_path)
    logger.info("=" * 60)
    await server.wait_closed()


if __name__ == "__main__":
    asyncio.run(main())