
import re
from core.database import SessionLocal, ParentChunk, Agent, init_db

init_db()
db = SessionLocal()

# Pizza Agent ID
agent_id = "08699428-93c7-450d-976a-013c0724a7d2"

try:
    # 1. Get all text for this agent's docs
    # We found the chunks are linked to source_doc_id=2 (Pizza Profile)
    chunks = db.query(ParentChunk).filter(ParentChunk.source_doc_id == 2).all()
    full_text = " ".join([c.content for c in chunks])
    
    # 2. Extract URLs (specifically unsplash ones as seen in dump)
    # The dump showed: https://images.unsplash.com/photo-...
    # We'll use a broad regex for http/https, handling the case where they might be followed by a space or *
    urls = re.findall(r'(https?://[a-zA-Z0-9\.\/\-_]+)', full_text)
    
    # Filter for image-like URLs just in case
    # Unsplash URLs don't always end in .jpg, but they are images.
    # The dump showed them as "Image Assets".
    image_urls = [u for u in urls if "unsplash" in u or u.endswith(('.jpg', '.png'))]
    
    print(f"Found {len(image_urls)} image URLs: {image_urls}")
    
    if image_urls:
        # 3. Update Agent
        agent = db.query(Agent).filter(Agent.id == agent_id).first()
        if agent:
            current_urls = agent.image_urls or []
            # Merge unique
            updated_urls = list(set(current_urls + image_urls))
            
            # Update DB
            agent.image_urls = updated_urls
            db.commit()
            print(f"✅ Updated Pizza Agent image_urls. New count: {len(updated_urls)}")
        else:
            print("❌ Pizza Agent not found in DB")
    else:
        print("⚠️ No image URLs found to update.")

finally:
    db.close()
