"""
PostgreSQL Database Models with pgvector support
"""
from typing import List, Dict, Optional
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey, Index, JSON, Float, text, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.sql import func
from pgvector.sqlalchemy import Vector
from .config import DATABASE_URL, EMBEDDING_DIM

# Database setup with connection pooling
engine = create_engine(
    DATABASE_URL, 
    echo=False,
    pool_size=20,           # Maintain 20 connections
    max_overflow=40,        # Allow up to 40 extra connections
    pool_pre_ping=True,     # Health check connections
    pool_recycle=3600,      # Recycle connections after 1 hour
    connect_args={
        "client_encoding": "utf8",
        "options": "-c client_encoding=utf8"
    }
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# ============== MODELS ==============

class Agent(Base):
    """Agent model for multi-agent support"""
    __tablename__ = "omni_agents"
    
    id = Column(String, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    description = Column(Text)
    system_prompt = Column(Text)  # Custom instructions
    system_prompt_source = Column(String, nullable=True)  # Original prompt path/name for display
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    document_count = Column(Integer, default=0)
    message_count = Column(Integer, default=0)
    extra_data = Column(JSON, default={})  # For future extension (renamed from metadata)

    # Added features
    role_type = Column(String, nullable=True) # e.g., "Personal Assistant", "Creative Helper"
    industry = Column(String, nullable=True) # e.g., "Healthcare", "Retail", etc. for business agents
    urls = Column(JSON, nullable=True) # List of URLs for scraping
    conversation_starters = Column(JSON, nullable=True) # List of example conversation starters
    image_urls = Column(JSON, nullable=True) # Optional image URLs
    video_urls = Column(JSON, nullable=True) # Optional video URLs
    scraped_data = Column(JSON, nullable=True) # Optional raw scraped content payload
    logic = Column(JSON, nullable=True) # Optional execution logic/config
    conversation_end = Column(JSON, nullable=True) # Optional end-of-conversation prompts/actions
    agent_type = Column(String, nullable=True) # Legacy/postman compatibility
    subagent_type = Column(String, nullable=True) # Legacy/postman compatibility
    model_selection = Column(String, nullable=True) # Requested model profile
    user_id = Column(String, nullable=True) # Owner/user from X-User-Id header
    
    # Relationships
    messages = relationship("Message", back_populates="agent", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="agent", cascade="all, delete-orphan")
    channels = relationship("Channel", back_populates="agent", cascade="all, delete-orphan")
    tools = relationship("Tool", back_populates="agent", cascade="all, delete-orphan")


# ============== MESSAGING MODELS (PHASE 2) ==============

class Channel(Base):
    """Channel configuration (WhatsApp, Voice, etc.)"""
    __tablename__ = "omni_channels"
    
    id = Column(String, primary_key=True) # UUID
    name = Column(String, nullable=False)
    type = Column(String, nullable=False) # 'whatsapp', 'voice', 'email'
    provider = Column(String) # 'meta', 'twilio', 'liquid'
    config = Column(JSON, default={}) # Credentials, tokens
    agent_id = Column(String, ForeignKey("omni_agents.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    agent = relationship("Agent", back_populates="channels")


class Tool(Base):
    """Messaging Tools (Flows, Buttons, Webhooks)"""
    __tablename__ = "omni_tools"
    
    id = Column(String, primary_key=True) # UUID
    name = Column(String, nullable=False)
    type = Column(String, nullable=False) # 'flow', 'button_reply', 'webhook', 'schedule', 'faq'
    content = Column(JSON, default={}) # Payload template
    agent_id = Column(String, ForeignKey("omni_agents.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    agent = relationship("Agent", back_populates="tools")


def ensure_schema_updates(engine):
    """Run ALTER TABLE commands to ensure new columns exist"""
    with engine.connect() as conn:
        with conn.begin():
            # role_type
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS role_type VARCHAR"))
            except Exception as e:
                print(f"Schema update (role_type) skipped/failed: {e}")

            # system_prompt_source
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS system_prompt_source VARCHAR"))
            except Exception as e:
                print(f"Schema update (system_prompt_source) skipped/failed: {e}")
                
            # urls
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS urls JSON"))
            except Exception as e:
                print(f"Schema update (urls) skipped/failed: {e}")
                
            # conversation_starters
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS conversation_starters JSON"))
            except Exception as e:
                print(f"Schema update (conversation_starters) skipped/failed: {e}")

            # industry
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS industry VARCHAR"))
            except Exception as e:
                print(f"Schema update (industry) skipped/failed: {e}")

            # image_urls
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS image_urls JSON"))
            except Exception as e:
                print(f"Schema update (image_urls) skipped/failed: {e}")

            # video_urls
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS video_urls JSON"))
            except Exception as e:
                print(f"Schema update (video_urls) skipped/failed: {e}")

            # scraped_data
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS scraped_data JSON"))
            except Exception as e:
                print(f"Schema update (scraped_data) skipped/failed: {e}")

            # logic
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS logic JSON"))
            except Exception as e:
                print(f"Schema update (logic) skipped/failed: {e}")

            # conversation_end
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS conversation_end JSON"))
            except Exception as e:
                print(f"Schema update (conversation_end) skipped/failed: {e}")

            # agent_type
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS agent_type VARCHAR"))
            except Exception as e:
                print(f"Schema update (agent_type) skipped/failed: {e}")

            # subagent_type
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS subagent_type VARCHAR"))
            except Exception as e:
                print(f"Schema update (subagent_type) skipped/failed: {e}")

            # model_selection
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS model_selection VARCHAR"))
            except Exception as e:
                print(f"Schema update (model_selection) skipped/failed: {e}")

            # user_id
            try:
                conn.execute(text("ALTER TABLE omni_agents ADD COLUMN IF NOT EXISTS user_id VARCHAR"))
            except Exception as e:
                print(f"Schema update (agent.user_id) skipped/failed: {e}")

            # usage.query_tokens
            try:
                conn.execute(text("ALTER TABLE omni_usage ADD COLUMN IF NOT EXISTS query_tokens INTEGER DEFAULT 0"))
            except Exception as e:
                print(f"Schema update (usage.query_tokens) skipped/failed: {e}")

            # usage.question_tokens -> usage.query_tokens (legacy compatibility)
            try:
                conn.execute(
                    text(
                        """
                        DO $$
                        BEGIN
                            IF EXISTS (
                                SELECT 1
                                FROM information_schema.columns
                                WHERE table_name = 'omni_usage' AND column_name = 'question_tokens'
                            ) THEN
                                UPDATE omni_usage
                                SET query_tokens = question_tokens
                                WHERE COALESCE(query_tokens, 0) = 0
                                  AND question_tokens IS NOT NULL;
                            END IF;
                        END
                        $$;
                        """
                    )
                )
            except Exception as e:
                print(f"Schema update (usage.question_tokens->usage.query_tokens) skipped/failed: {e}")

            # usage.rag_query_tokens
            try:
                conn.execute(text("ALTER TABLE omni_usage ADD COLUMN IF NOT EXISTS rag_query_tokens INTEGER DEFAULT 0"))
            except Exception as e:
                print(f"Schema update (usage.rag_query_tokens) skipped/failed: {e}")

            # Backfill dedicated columns from legacy extra_data payload (one-time compatibility migration).
            try:
                conn.execute(
                    text(
                        """
                        UPDATE omni_agents
                        SET
                            system_prompt_source = COALESCE(system_prompt_source, extra_data::jsonb ->> 'system_prompt_source'),
                            logic = COALESCE(logic, (extra_data::jsonb -> 'logic')::json),
                            conversation_end = COALESCE(conversation_end, (extra_data::jsonb -> 'conversation_end')::json),
                            agent_type = COALESCE(agent_type, extra_data::jsonb ->> 'agent_type'),
                            subagent_type = COALESCE(subagent_type, extra_data::jsonb ->> 'subagent_type'),
                            model_selection = COALESCE(model_selection, extra_data::jsonb ->> 'model_selection')
                        WHERE extra_data IS NOT NULL
                        """
                    )
                )
                conn.execute(
                    text(
                        """
                        UPDATE omni_agents
                        SET extra_data = (extra_data::jsonb
                            - 'system_prompt_source'
                            - 'logic'
                            - 'conversation_end'
                            - 'agent_type'
                            - 'subagent_type'
                            - 'model_selection')::json
                        WHERE extra_data IS NOT NULL
                        """
                    )
                )
            except Exception as e:
                print(f"Schema update (backfill dedicated agent columns) skipped/failed: {e}")

            # Phase 3: Document Status
            try:
                conn.execute(text("ALTER TABLE omni_documents ADD COLUMN IF NOT EXISTS status VARCHAR DEFAULT 'uploading'"))
            except Exception as e:
                print(f"Schema update (document.status) skipped/failed: {e}")

            # Semantic cache embedding dimension alignment for upgraded embedding models.
            try:
                conn.execute(text("DROP INDEX IF EXISTS idx_cache_embedding_hnsw"))
            except Exception as e:
                print(f"Schema update (drop idx_cache_embedding_hnsw) skipped/failed: {e}")

            try:
                conn.execute(
                    text(
                        f"ALTER TABLE omni_semantic_cache "
                        f"ALTER COLUMN embedding TYPE vector({EMBEDDING_DIM})"
                    )
                )
            except Exception as e:
                # Cache is disposable; clear stale rows and retry when dimensions changed.
                print(f"Schema update (semantic cache vector dim) retrying after truncate: {e}")
                try:
                    conn.execute(text("TRUNCATE TABLE omni_semantic_cache"))
                    conn.execute(
                        text(
                            f"ALTER TABLE omni_semantic_cache "
                            f"ALTER COLUMN embedding TYPE vector({EMBEDDING_DIM})"
                        )
                    )
                except Exception as e2:
                    print(f"Schema update (semantic cache vector dim) skipped/failed: {e2}")




class Session(Base):
    """Session model for tracking user interactions"""
    __tablename__ = "omni_sessions"
    
    id = Column(String, primary_key=True) # UUID
    agent_id = Column(String, ForeignKey("omni_agents.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(String, nullable=False) # Phone number or session ID
    start_time = Column(DateTime(timezone=True), server_default=func.now())
    end_time = Column(DateTime(timezone=True), nullable=True)
    duration = Column(Float, default=0.0) # Seconds
    status = Column(String, default="active") # active, completed, timeout
    channel_type = Column(String, default="web") # whatsapp, voice, web
    
    agent = relationship("Agent")

class Message(Base):
    """Message model for conversation history"""
    __tablename__ = "omni_messages"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    agent_id = Column(String, ForeignKey("omni_agents.id", ondelete="CASCADE"))
    role = Column(String, nullable=False)  # 'user' or 'assistant'
    content = Column(Text, nullable=False)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    
    agent = relationship("Agent", back_populates="messages")
    
    __table_args__ = (
        Index('idx_omni_agent_messages', 'agent_id', 'timestamp'),
    )


class Document(Base):
    """Document model for tracking uploaded files"""
    __tablename__ = "omni_documents"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    agent_id = Column(String, ForeignKey("omni_agents.id", ondelete="CASCADE"), nullable=False)
    filename = Column(String, nullable=False)
    file_type = Column(String)
    file_size = Column(Integer)
    content_preview = Column(Text)
    chunk_count = Column(Integer, default=0)
    uploaded_at = Column(DateTime(timezone=True), server_default=func.now())
    extra_data = Column(JSON, default={})
    embedding_time = Column(Float, default=0.0)  # Time taken to embed
    status = Column(String, default="uploading") # uploading, indexing, ready, error
    
    agent = relationship("Agent", back_populates="documents")
    
    __table_args__ = (
        Index('idx_omni_agent_documents', 'agent_id'),
    )


class UsageLog(Base):
    """Usage log for tracking tokens and cost"""
    __tablename__ = "omni_usage"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    agent_id = Column(String, ForeignKey("omni_agents.id", ondelete="SET NULL"))
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    query_tokens = Column(Integer, default=0)
    rag_query_tokens = Column(Integer, default=0)
    prompt_tokens = Column(Integer, default=0)
    completion_tokens = Column(Integer, default=0)
    total_tokens = Column(Integer, default=0)
    model_name = Column(String)
    cost = Column(Float, default=0.0)
    latency = Column(Float, default=0.0)  # API latency in seconds
    
    agent = relationship("Agent")


class ApiKey(Base):
    """API Key for authentication"""
    __tablename__ = "omni_api_keys"
    
    key = Column(String, primary_key=True)
    owner = Column(String)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class WebhookLog(Base):
    """Webhook log for capturing incoming webhooks"""
    __tablename__ = "omni_webhook_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    received_at = Column(DateTime(timezone=True), server_default=func.now())
    method = Column(String, nullable=False)
    url = Column(String, nullable=False)
    query_params = Column(Text)
    headers = Column(Text)  # JSON string
    body = Column(Text)  # JSON string
    source_ip = Column(String)
    
    __table_args__ = (
        Index('idx_omni_webhook_received', 'received_at'),
    )


class ParentChunk(Base):
    """Store large parent chunks for small-to-large retrieval"""
    __tablename__ = "omni_parent_chunks"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    content = Column(Text, nullable=False)
    source_doc_id = Column(Integer, ForeignKey("omni_documents.id", ondelete="CASCADE"), nullable=True)
    
    # Since children are in VectorDB (pgvector table), we just persist ID here.


class SemanticCache(Base):
    """Semantic Cache for frequent queries using pgvector"""
    __tablename__ = "omni_semantic_cache"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    question = Column(Text, nullable=False)
    embedding = Column(Vector(EMBEDDING_DIM))
    answer = Column(Text, nullable=False)
    agent_id = Column(String, nullable=True)  # Optional: Cache per agent
    hit_count = Column(Integer, default=1)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # We'll create HNSW index via SQL or relying on pgvector extension defaults
    # For now, standard table definition is enough for SQLAlchemy to map it.


# ============== DATABASE OPERATIONS ==============


def init_db():
    """Initialize database tables and performance indexes"""
    Base.metadata.create_all(bind=engine)
    ensure_schema_updates(engine) # Run manual schema updates (ALTER TABLE)
    print("[OK] OmniCortex database tables created")
    
    # Create performance indexes (idempotent)
    db = SessionLocal()
    try:
        # HNSW Index for Semantic Cache (fast vector similarity)
        db.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_cache_embedding_hnsw 
            ON omni_semantic_cache 
            USING hnsw(embedding vector_cosine_ops)
            WITH (m = 16, ef_construction = 64);
        """))
        
        # GIN Index for Full-Text Search on Parent Chunks
        db.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_parent_fts 
            ON omni_parent_chunks 
            USING GIN(to_tsvector('english', content));
        """))
        
        db.commit()
        print("[OK] Performance indexes created (HNSW + GIN)")
    except Exception as e:
        print(f"[WARN] Index creation skipped: {e}")
        db.rollback()
    finally:
        db.close()


def get_session():
    """Get database session"""
    return SessionLocal()

# Usage Operations
def log_usage(
    agent_id: str,
    prompt_tokens: int,
    completion_tokens: int,
    model_name: str,
    latency: float = 0.0,
    query_tokens: int = 0,
    rag_query_tokens: int = 0,
):
    """Log token usage and latency"""
    db = SessionLocal()
    try:
        # Simple cost estimation
        cost_input = 0.0
        cost_output = 0.0
        
        if "llama-3" in model_name.lower():
            cost_input = (prompt_tokens / 1_000_000) * 0.50
            cost_output = (completion_tokens / 1_000_000) * 0.70
            
        total_tokens = prompt_tokens + completion_tokens
        total_cost = cost_input + cost_output
        
        log = UsageLog(
            agent_id=agent_id,
            query_tokens=query_tokens or 0,
            rag_query_tokens=rag_query_tokens or 0,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            model_name=model_name,
            cost=total_cost,
            latency=latency
        )
        db.add(log)
        db.commit()
    finally:
        db.close()


def get_usage_stats(limit: int = 100):
    """Get usage statistics"""
    db = SessionLocal()
    try:
        logs = db.query(UsageLog).order_by(UsageLog.timestamp.desc()).limit(limit).all()
        return [
            {
                "timestamp": l.timestamp,
                "agent_id": l.agent_id,
                "model": l.model_name,
                "query_tokens": getattr(l, "query_tokens", 0),
                "rag_query_tokens": getattr(l, "rag_query_tokens", 0),
                "total_tokens": l.total_tokens,
                "prompt_tokens": l.prompt_tokens,
                "completion_tokens": l.completion_tokens,
                "cost": l.cost,
                "latency": getattr(l, 'latency', 0.0)
            }
            for l in logs
        ]
    finally:
        db.close()


# Webhook Log Operations
def save_webhook_log(method: str, url: str, query_params: str = None, 
                     headers: str = None, body: str = None, source_ip: str = None):
    """Save incoming webhook to database"""
    db = SessionLocal()
    try:
        log = WebhookLog(
            method=method,
            url=url,
            query_params=query_params,
            headers=headers,
            body=body,
            source_ip=source_ip
        )
        db.add(log)
        db.commit()
        return log.id
    finally:
        db.close()


def get_webhook_logs(limit: int = 50, offset: int = 0):
    """Get webhook logs with pagination"""
    db = SessionLocal()
    try:
        total = db.query(WebhookLog).count()
        logs = db.query(WebhookLog).order_by(WebhookLog.received_at.desc()).offset(offset).limit(limit).all()
        return {
            "total": total,
            "logs": [
                {
                    "id": l.id,
                    "received_at": l.received_at,
                    "method": l.method,
                    "url": l.url,
                    "query_params": l.query_params,
                    "headers": l.headers,
                    "body": l.body,
                    "source_ip": l.source_ip
                }
                for l in logs
            ]
        }
    finally:
        db.close()


def clear_webhook_logs():
    """Clear all webhook logs"""
    db = SessionLocal()
    try:
        db.query(WebhookLog).delete()
        db.commit()
    finally:
        db.close()


# Message Operations
def save_message(role: str, content: str, agent_id: str = None):
    """Save a message to the database"""
    db = SessionLocal()
    try:
        message = Message(agent_id=agent_id, role=role, content=content)
        db.add(message)
        
        if agent_id:
            agent = db.query(Agent).filter(Agent.id == agent_id).first()
            if agent:
                agent.message_count = (agent.message_count or 0) + 1
        
        db.commit()
    finally:
        db.close()


def get_conversation_history(agent_id: str = None, limit: int = None) -> List[Dict]:
    """Get conversation history"""
    db = SessionLocal()
    try:
        query = db.query(Message).order_by(Message.timestamp.desc())
        if agent_id:
            query = query.filter(Message.agent_id == agent_id)
        if limit:
            query = query.limit(limit)
        
        messages = query.all()
        return [
            {"role": msg.role, "content": msg.content, 
             "timestamp": msg.timestamp.isoformat() if msg.timestamp else None}
            for msg in reversed(messages)
        ]
    finally:
        db.close()


def clear_history(agent_id: str = None):
    """Clear conversation history"""
    db = SessionLocal()
    try:
        query = db.query(Message)
        if agent_id:
            query = query.filter(Message.agent_id == agent_id)
        query.delete()
        db.commit()
    finally:
        db.close()

# Document Operations
def save_document_metadata(agent_id: str, filename: str, file_type: str = None,
                          file_size: int = None, content_preview: str = None,
                          chunk_count: int = 0, metadata: dict = None,
                          embedding_time: float = 0.0) -> int:
    """Save document metadata"""
    db = SessionLocal()
    try:
        doc = Document(
            agent_id=agent_id,
            filename=filename,
            file_type=file_type,
            file_size=file_size,
            content_preview=content_preview[:500] if content_preview else None,
            chunk_count=chunk_count,
            extra_data=metadata or {},
            embedding_time=embedding_time
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)
        return doc.id
    finally:
        db.close()


def get_agent_documents(agent_id: str) -> List[Dict]:
    """Get all documents for an agent"""
    db = SessionLocal()
    try:
        docs = db.query(Document).filter(Document.agent_id == agent_id).order_by(Document.uploaded_at.desc()).all()
        return [
            {
                "id": doc.id,
                "filename": doc.filename,
                "file_type": doc.file_type,
                "file_size": doc.file_size,
                "content_preview": doc.content_preview,
                "chunk_count": doc.chunk_count,
                "uploaded_at": doc.uploaded_at.isoformat() if doc.uploaded_at else None,
                "metadata": doc.extra_data,
                "embedding_time": getattr(doc, 'embedding_time', 0.0)
            }
            for doc in docs
        ]
    finally:
        db.close()


def get_agent_document_names(agent_id: str, limit: int = 50) -> List[str]:
    """Get recent document filenames for an agent with a bounded result set."""
    db = SessionLocal()
    try:
        rows = (
            db.query(Document.filename)
            .filter(Document.agent_id == agent_id)
            .order_by(Document.uploaded_at.desc())
            .limit(limit)
            .all()
        )
        return [row[0] for row in rows if row and row[0]]
    finally:
        db.close()


def delete_document(document_id: int) -> bool:
    """Delete a document and update agent count"""
    db = SessionLocal()
    try:
        doc = db.query(Document).filter(Document.id == document_id).first()
        if doc:
            agent_id = doc.agent_id
            db.delete(doc)
            
            # Update agent document count
            if agent_id:
                agent = db.query(Agent).filter(Agent.id == agent_id).first()
                if agent and agent.document_count > 0:
                    agent.document_count = agent.document_count - 1
            
            db.commit()
            return True
        return False
    finally:
        db.close()


# Parent Chunk Operations
def save_parent_chunk(content: str, source_doc_id: int = None) -> int:
    """Save a parent chunk and return its ID"""
    db = SessionLocal()
    try:
        chunk = ParentChunk(content=content, source_doc_id=source_doc_id)
        db.add(chunk)
        db.commit()
        db.refresh(chunk)
        return chunk.id
    finally:
        db.close()


def batch_save_parent_chunks(chunks: list, source_doc_id: int = None) -> Dict[str, int]:
    """
    Batch save multiple parent chunks in a single transaction.
    Returns mapping of chunk content to database row ID.
    
    Args:
        chunks: List of unique parent content strings
        source_doc_id: Optional document ID to link
    
    Returns:
        Dict mapping content -> id
    """
    db = SessionLocal()
    try:
        content_to_id = {}
        objects = []
        
        for content in chunks:
            obj = ParentChunk(content=content, source_doc_id=source_doc_id)
            objects.append(obj)
        
        db.add_all(objects)
        db.flush()
        
        # Map content to IDs
        for obj in objects:
            if obj.id is not None:
                content_to_id[obj.content] = obj.id

        db.commit()
            
        print(f"✅ Batch saved {len(objects)} parent chunks")
        return content_to_id
        
    except Exception as e:
        print(f"⚠️ Batch save failed: {e}")
        db.rollback()
        return {}
    finally:
        db.close()


def get_parent_chunk(chunk_id: int) -> str:
    """Get content of a parent chunk"""
    db = SessionLocal()
    try:
        chunk = db.query(ParentChunk).filter(ParentChunk.id == chunk_id).first()
        return chunk.content if chunk else None
    finally:
        db.close()


