
import sys
import os
# Add current directory to path so we can import core
sys.path.append(os.getcwd())

from core.response_parser import parse_response, replace_image_tags_with_urls
from core.database import SessionLocal, Agent, init_db

# Init DB to ensure tables exist
init_db()

# Create a mock agent entry in DB if needed, or just mock the function
# But since response_parser imports get_agent, we can just mock get_agent
from unittest.mock import MagicMock
import core.response_parser

# Mock agent data
mock_agent = {
    "id": "test_agent_123",
    "name": "TestAgent",
    "image_urls": [
        "https://example.com/sunset.jpg",
        "https://example.com/mountain.png"
    ]
}

# Monkey patch get_agent
core.response_parser.get_agent = MagicMock(return_value=mock_agent)

def test_parsing():
    print("--- Testing parse_response ---")
    # Test 1: Single image
    answer = "Here is a sunset: [image][sunset.jpg]"
    parts = parse_response(answer, "test_agent_123")
    print(f"Input: {answer}")
    print(f"Output: {parts}")
    assert len(parts) == 2, "Should have 2 parts"
    assert parts[1]["type"] == "image", "Second part should be image"
    assert parts[1]["url"] == "https://example.com/sunset.jpg", "URL mismatch"

    # Test 2: Multiple images and text
    answer = "Look: [image][sunset.jpg] and [image][mountain.png]"
    parts = parse_response(answer, "test_agent_123")
    print(f"Input: {answer}")
    print(f"Output: {parts}")
    assert len(parts) == 4, "Should have 4 parts (text, image, text, image)"
    
    print("\n--- Testing replace_image_tags_with_urls ---")
    # Test 3: Replacement
    answer = "Here is [image][sunset.jpg] for you."
    replaced = replace_image_tags_with_urls(answer, "test_agent_123")
    print(f"Input: {answer}")
    print(f"Output: {replaced}")
    assert "https://example.com/sunset.jpg" in replaced, "URL not substituted"
    assert "[image]" not in replaced, "Tag still present"

    print("\n✅ All tests passed!")

if __name__ == "__main__":
    try:
        test_parsing()
    except AssertionError as e:
        print(f"❌ Test Failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)
