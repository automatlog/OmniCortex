const WebSocket = require('ws');

// ── Configuration ─────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || '9001');
const API_KEY = process.env.RUNPOD_API_KEY || '';
const MOSHI_LOCAL_URL = process.env.MOSHI_LOCAL_URL || 'ws://127.0.0.1:8998/api/chat';
const DEFAULT_TEXT_PROMPT = process.env.DEFAULT_TEXT_PROMPT || 'You are a helpful voice assistant. Be concise and friendly.';

// Audio rates
const MOSHI_RATE = 24000;
const BRIDGE_RATE = parseInt(process.env.BRIDGE_RATE || '8000'); // FreeSWITCH L16

// Opus: 20ms frame at 24kHz = 480 samples
const OPUS_FRAME_SAMPLES = 480;
const OPUS_FRAME_BYTES = OPUS_FRAME_SAMPLES * 2; // 16-bit PCM = 960 bytes

// ── Opus Setup ────────────────────────────────────────────────────
let OpusEncoder;
try {
    OpusEncoder = require('@discordjs/opus').OpusEncoder;
} catch (e) {
    try {
        OpusEncoder = require('opusscript');
    } catch (e2) {
        console.error('ERROR: No Opus library found!');
        console.error('Install one: npm install @discordjs/opus');
        console.error('         or: npm install opusscript');
        console.error('');
        console.error('If @discordjs/opus fails to compile, use ai_server.py instead (uses sphn).');
        process.exit(1);
    }
}

// ── Resample ──────────────────────────────────────────────────────
function resample(pcm16Buf, fromRate, toRate) {
    if (fromRate === toRate) return pcm16Buf;

    const samples = pcm16Buf.length / 2;
    const ratio = toRate / fromRate;
    const outSamples = Math.floor(samples * ratio);
    const out = Buffer.alloc(outSamples * 2);

    for (let i = 0; i < outSamples; i++) {
        const srcIdx = i / ratio;
        const left = Math.floor(srcIdx);
        const right = Math.min(left + 1, samples - 1);
        const frac = srcIdx - left;

        const lVal = pcm16Buf.readInt16LE(left * 2);
        const rVal = pcm16Buf.readInt16LE(right * 2);
        const val = Math.round(lVal * (1 - frac) + rVal * frac);
        out.writeInt16LE(Math.max(-32768, Math.min(32767, val)), i * 2);
    }
    return out;
}

// ── WebSocket Server ──────────────────────────────────────────────
const wss = new WebSocket.Server({
    port: PORT,
    verifyClient: (info, cb) => {
        if (!API_KEY) return cb(true);
        const xApiKey = info.req.headers['x-api-key'] || '';
        const authHeader = info.req.headers['authorization'] || '';
        const bearerKey = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';
        const url = new URL(info.req.url, `http://localhost:${PORT}`);
        const tokenParam = url.searchParams.get('token') || '';
        if (xApiKey === API_KEY || bearerKey === API_KEY || tokenParam === API_KEY) {
            return cb(true);
        }
        console.log(`[!] Unauthorized from ${info.req.socket.remoteAddress}`);
        return cb(false, 401, 'Unauthorized');
    }
});

console.log(`AI Server (Node/Opus) on port ${PORT}`);
console.log(`Auth: ${API_KEY ? 'ENABLED' : 'DISABLED'}`);
console.log(`Moshi backend: ${MOSHI_LOCAL_URL}`);
console.log(`Bridge PCM: ${BRIDGE_RATE} Hz -> Moshi: ${MOSHI_RATE} Hz`);

wss.on('connection', (clientWs, req) => {
    const peer = req.socket.remoteAddress;

    // Build Moshi URL with text_prompt
    const clientUrl = new URL(req.url, `http://localhost:${PORT}`);
    if (!clientUrl.searchParams.has('text_prompt')) {
        clientUrl.searchParams.set('text_prompt', DEFAULT_TEXT_PROMPT);
    }
    const queryString = clientUrl.searchParams.toString();
    const moshiUrl = `${MOSHI_LOCAL_URL}${MOSHI_LOCAL_URL.includes('?') ? '&' : '?'}${queryString}`;
    console.log(`[+] Client from ${peer} -> Moshi at ${moshiUrl}`);

    // Per-connection Opus encoder/decoder
    let encoder, decoder;
    try {
        if (OpusEncoder.prototype && OpusEncoder.prototype.encode) {
            // @discordjs/opus style
            encoder = new OpusEncoder(MOSHI_RATE, 1);
            decoder = new OpusEncoder(MOSHI_RATE, 1);
        } else {
            // opusscript style
            encoder = new OpusEncoder(MOSHI_RATE, 1, OpusEncoder.Application ? OpusEncoder.Application.AUDIO : 2049);
            decoder = encoder; // opusscript uses same instance
        }
    } catch (e) {
        console.error('[opus] Failed to create encoder:', e.message);
        clientWs.close(1011, 'Opus init failed');
        return;
    }

    // PCM buffer for accumulating samples until we have a full Opus frame
    let pcmBuffer = Buffer.alloc(0);
    let txFrames = 0;
    let rxFrames = 0;

    // Connect to Moshi
    const moshiHeaders = {};
    if (API_KEY) moshiHeaders['x-api-key'] = API_KEY;
    const moshiWs = new WebSocket(moshiUrl, { headers: moshiHeaders });

    moshiWs.on('open', () => console.log('[moshi] Connected to backend'));

    // ── Bridge -> Moshi (Raw PCM -> Opus) ─────────────────────────
    clientWs.on('message', (data) => {
        if (!Buffer.isBuffer(data) || data.length === 0) return;
        if (moshiWs.readyState !== WebSocket.OPEN) return;

        // Resample bridge rate -> Moshi rate
        let pcm16 = resample(data, BRIDGE_RATE, MOSHI_RATE);

        // Accumulate PCM until we have full Opus frames
        pcmBuffer = Buffer.concat([pcmBuffer, pcm16]);

        while (pcmBuffer.length >= OPUS_FRAME_BYTES) {
            const frame = pcmBuffer.subarray(0, OPUS_FRAME_BYTES);
            pcmBuffer = pcmBuffer.subarray(OPUS_FRAME_BYTES);

            try {
                const opusPacket = encoder.encode(frame);
                // Send as kind=1 (audio) + Opus packet
                const msg = Buffer.concat([Buffer.from([0x01]), opusPacket]);
                moshiWs.send(msg);
                txFrames++;
                if (txFrames <= 3 || txFrames % 500 === 0) {
                    console.log(`[>] #${txFrames} PCM(${frame.length}B) -> Opus(${opusPacket.length}B) -> Moshi`);
                }
            } catch (e) {
                if (txFrames === 0) console.error('[opus] Encode error:', e.message);
            }
        }
    });

    // ── Moshi -> Bridge (Opus -> Raw PCM) ─────────────────────────
    moshiWs.on('message', (data) => {
        if (!Buffer.isBuffer(data) || data.length === 0) return;

        const kind = data[0];
        const payload = data.subarray(1);

        if (kind === 0x00) {
            // Handshake — Moshi ready
            console.log('[<] Handshake from Moshi');
            return;
        }

        if (kind === 0x01 && payload.length > 0) {
            // Audio: Opus decode -> resample -> raw PCM to bridge
            try {
                const pcm16 = decoder.decode(payload);
                const resampled = resample(pcm16, MOSHI_RATE, BRIDGE_RATE);
                if (clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(resampled);
                    rxFrames++;
                    if (rxFrames <= 3 || rxFrames % 500 === 0) {
                        console.log(`[<] #${rxFrames} Opus(${payload.length}B) -> PCM(${resampled.length}B) -> Bridge`);
                    }
                }
            } catch (e) {
                // Opus decode failed — likely sphn format mismatch
                // Fall back: try sending raw payload
                if (rxFrames === 0) {
                    console.error(`[opus] Decode error: ${e.message}`);
                    console.error('[opus] WARNING: sphn Opus format may not match @discordjs/opus.');
                    console.error('[opus] If audio is garbled, use ai_server.py instead.');
                }
                if (clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(payload);
                    rxFrames++;
                }
            }
            return;
        }

        if (kind === 0x02) {
            // Text token — log it
            const text = payload.toString('utf-8');
            process.stdout.write(text);
            return;
        }

        if (kind === 0x03) {
            const label = payload.toString('utf-8');
            console.log(`[<] Special: ${label}`);
            return;
        }
    });

    // ── Error / Close ─────────────────────────────────────────────
    moshiWs.on('error', (err) => {
        console.error(`[moshi] Error: ${err.message}`);
        if (clientWs.readyState === WebSocket.OPEN) clientWs.close(1011, 'Moshi error');
    });
    clientWs.on('error', (err) => console.error(`[client] Error: ${err.message}`));

    moshiWs.on('close', (code) => {
        console.log(`[moshi] Closed (code=${code}, tx=${txFrames} rx=${rxFrames})`);
        if (clientWs.readyState === WebSocket.OPEN) clientWs.close();
    });
    clientWs.on('close', () => {
        console.log(`[-] Client disconnected (tx=${txFrames} rx=${rxFrames})`);
        if (moshiWs.readyState === WebSocket.OPEN) moshiWs.close();
    });
});
