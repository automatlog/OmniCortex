type ENV = {
  VITE_QUEUE_API_PATH: string;
  VITE_ENV: 'development' | 'production';
  VITE_CALL_TRIGGER_URL: string;
  VITE_CALL_TRIGGER_METHOD: 'GET' | 'POST';
};

const parseEnv = (): ENV => {
  const VITE_QUEUE_API_PATH = import.meta.env.VITE_QUEUE_API_PATH;
  
  if (!VITE_QUEUE_API_PATH) {
    throw new Error("VITE_QUEUE_API_PATH is not defined");
  }

  return {
    VITE_QUEUE_API_PATH,
    VITE_ENV: import.meta.env.DEV ? 'development' : 'production',
    VITE_CALL_TRIGGER_URL: (import.meta.env.VITE_CALL_TRIGGER_URL || "").toString(),
    VITE_CALL_TRIGGER_METHOD: (
      String(import.meta.env.VITE_CALL_TRIGGER_METHOD || "GET").toUpperCase() === "POST"
        ? "POST"
        : "GET"
    ),
  };
};

export const env = parseEnv();
