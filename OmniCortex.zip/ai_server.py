#!/usr/bin/env python3
"""
Opus-transcoding WebSocket proxy for Moshi.

Sits between bridge.js (raw PCM) and Moshi Python server (Opus).

Bridge.js  -->  [kind=1 + raw PCM]  -->  ai_server.py  -->  [kind=1 + Opus]  -->  Moshi
Bridge.js  <--  [kind=1 + raw PCM]  <--  ai_server.py  <--  [kind=1 + Opus]  <--  Moshi

Also handles auth (x-api-key), text_prompt injection, and non-audio frame passthrough.
"""

import asyncio
import os
import struct
import signal
import sys
import time
from contextlib import suppress
from urllib.parse import urlencode, urlparse, parse_qs, urlunparse

import numpy as np
import sphn
import websockets
from websockets.legacy.server import serve

# ── Configuration ──────────────────────────────────────────────────
PORT = int(os.environ.get("PORT", "9001"))
API_KEY = os.environ.get("RUNPOD_API_KEY", "")
MOSHI_LOCAL_URL = os.environ.get("MOSHI_LOCAL_URL", "ws://127.0.0.1:8998/api/chat")
DEFAULT_TEXT_PROMPT = os.environ.get(
    "DEFAULT_TEXT_PROMPT",
    "You are a helpful voice assistant. Be concise and friendly.",
)

MOSHI_RATE = 24000  # Moshi's native sample rate (24kHz — hardcoded in model, do not change)
BRIDGE_RATE = int(os.environ.get("BRIDGE_RATE", "16000"))  # FreeSWITCH L16 rate
SILENCE_GATE_ENABLED = os.environ.get("AI_SERVER_SILENCE_GATE", "true").strip().lower() == "true"
SILENCE_RMS_THRESHOLD = float(os.environ.get("AI_SERVER_SILENCE_RMS_THRESHOLD", "0.003"))
SILENCE_MIN_FRAMES = int(os.environ.get("AI_SERVER_SILENCE_MIN_FRAMES", "40"))
FRAME_DEBUG = os.environ.get("FRAME_DEBUG", "false").strip().lower() == "true"
FRAME_DEBUG_MAX_FRAMES = int(os.environ.get("FRAME_DEBUG_MAX_FRAMES", "25"))
FRAME_DEBUG_EVERY = int(os.environ.get("FRAME_DEBUG_EVERY", "100"))
FRAME_DEBUG_HEX_BYTES = int(os.environ.get("FRAME_DEBUG_HEX_BYTES", "16"))
FRAME_DEBUG_PCM_SAMPLES = int(os.environ.get("FRAME_DEBUG_PCM_SAMPLES", "8"))
TRANSCRIBE_INBOUND_AUDIO = os.environ.get("TRANSCRIBE_INBOUND_AUDIO", "false").strip().lower() == "true"
TRANSCRIBE_MODEL = os.environ.get("TRANSCRIBE_MODEL", "base.en").strip()
TRANSCRIBE_DEVICE = os.environ.get("TRANSCRIBE_DEVICE", os.environ.get("VOICE_ASR_DEVICE", "cpu")).strip()
TRANSCRIBE_MIN_SECONDS = float(os.environ.get("TRANSCRIBE_MIN_SECONDS", "1.0"))
TRANSCRIBE_END_SILENT_FRAMES = int(os.environ.get("TRANSCRIBE_END_SILENT_FRAMES", "10"))
SUPPRESSED_SPECIAL_TOKENS = {
    token.strip().upper()
    for token in os.environ.get("MOSHI_SUPPRESS_SPECIAL_TOKENS", "PAD,EPAD").split(",")
    if token.strip()
}

print(f"AI Server (Python/Opus) on port {PORT}")
print(f"Auth: {'ENABLED' if API_KEY else 'DISABLED'}")
print(f"Moshi backend: {MOSHI_LOCAL_URL}")
print(f"Bridge PCM rate: {BRIDGE_RATE} Hz | Moshi rate: {MOSHI_RATE} Hz")
if SILENCE_GATE_ENABLED:
    print(
        f"Silence gate: ENABLED "
        f"(rms<{SILENCE_RMS_THRESHOLD}, hold={SILENCE_MIN_FRAMES} frames)"
    )
else:
    print("Silence gate: DISABLED")
if FRAME_DEBUG:
    print(
        f"Frame debug: ENABLED "
        f"(first={FRAME_DEBUG_MAX_FRAMES}, every={FRAME_DEBUG_EVERY}, "
        f"hex={FRAME_DEBUG_HEX_BYTES}B, pcm_samples={FRAME_DEBUG_PCM_SAMPLES})"
    )
if TRANSCRIBE_INBOUND_AUDIO:
    print(
        f"Inbound ASR debug: ENABLED "
        f"(model={TRANSCRIBE_MODEL}, device={TRANSCRIBE_DEVICE}, "
        f"min={TRANSCRIBE_MIN_SECONDS}s, end_silence={TRANSCRIBE_END_SILENT_FRAMES})"
    )


# ── Helpers ────────────────────────────────────────────────────────
def resample(pcm: np.ndarray, from_rate: int, to_rate: int) -> np.ndarray:
    """Simple linear-interpolation resample."""
    if from_rate == to_rate:
        return pcm
    ratio = to_rate / from_rate
    n_out = int(len(pcm) * ratio)
    indices = np.arange(n_out) / ratio
    left = np.floor(indices).astype(int)
    left = np.clip(left, 0, len(pcm) - 1)
    right = np.clip(left + 1, 0, len(pcm) - 1)
    frac = indices - left
    return pcm[left] * (1 - frac) + pcm[right] * frac


def pcm16_bytes_to_float32(data: bytes) -> np.ndarray:
    """L16 (signed 16-bit little-endian) bytes → float32 [-1, 1]."""
    pcm16 = np.frombuffer(data, dtype="<i2")
    return pcm16.astype(np.float32) / 32768.0


def float32_to_pcm16_bytes(pcm: np.ndarray) -> bytes:
    """float32 [-1, 1] → L16 signed 16-bit LE bytes."""
    pcm = np.clip(pcm, -1.0, 1.0)
    return (pcm * 32767).astype("<i2").tobytes()


def pcm_rms(pcm: np.ndarray) -> float:
    """Compute RMS energy for a mono PCM float32 frame."""
    if pcm.size == 0:
        return 0.0
    return float(np.sqrt(np.mean(np.square(pcm, dtype=np.float64))))


def should_log_frame(index: int) -> bool:
    """Limit noisy frame-level diagnostics."""
    if not FRAME_DEBUG or index <= 0:
        return False
    if index <= FRAME_DEBUG_MAX_FRAMES:
        return True
    return FRAME_DEBUG_EVERY > 0 and index % FRAME_DEBUG_EVERY == 0


def bytes_preview(data: bytes, limit: int = FRAME_DEBUG_HEX_BYTES) -> str:
    """Render a short hex preview for any frame."""
    return " ".join(f"{byte:02x}" for byte in data[:limit])


def pcm_preview(data: bytes, samples: int = FRAME_DEBUG_PCM_SAMPLES) -> str:
    """Render a short int16 preview for PCM frames."""
    if len(data) < 2:
        return ""
    preview = np.frombuffer(data[: samples * 2], dtype="<i2")
    return ",".join(str(int(value)) for value in preview)


def log_pcm_frame(label: str, index: int, data: bytes, sample_rate: int) -> None:
    """Log PCM frame stats and a short preview."""
    if not should_log_frame(index):
        return
    pcm = pcm16_bytes_to_float32(data)
    peak = float(np.max(np.abs(pcm))) if pcm.size else 0.0
    print(
        f"[frame] {label}#{index} {len(data)}B {len(data) // 2}smp@{sample_rate}Hz "
        f"rms={pcm_rms(pcm):.6f} peak={peak:.6f} "
        f"i16=[{pcm_preview(data)}] hex=[{bytes_preview(data)}]"
    )


def log_binary_frame(label: str, index: int, data: bytes) -> None:
    """Log non-PCM frame stats and a short hex preview."""
    if not should_log_frame(index):
        return
    print(f"[frame] {label}#{index} {len(data)}B hex=[{bytes_preview(data)}]")


class DebugTranscriber:
    """Optional rolling ASR for received bridge audio."""

    def __init__(self):
        self._model = None
        self._failed = False

    def _load_model(self):
        if self._model is not None:
            return
        from faster_whisper import WhisperModel

        compute_type = "float16" if TRANSCRIBE_DEVICE == "cuda" else "int8"
        self._model = WhisperModel(TRANSCRIBE_MODEL, device=TRANSCRIBE_DEVICE, compute_type=compute_type)

    def _transcribe_sync(self, pcm_float32: np.ndarray) -> str:
        self._load_model()
        segments, _info = self._model.transcribe(pcm_float32, beam_size=3, language="en")
        return " ".join(segment.text.strip() for segment in segments).strip()

    async def transcribe(self, pcm_float32: np.ndarray) -> str:
        if self._failed:
            return ""
        try:
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, self._transcribe_sync, pcm_float32)
        except Exception as exc:
            self._failed = True
            print(f"[asr] Disabled after error: {type(exc).__name__}: {exc}")
            return ""


def build_moshi_url(client_path: str) -> str:
    """Build Moshi backend URL, injecting text_prompt if missing."""
    parsed = urlparse(MOSHI_LOCAL_URL)
    existing_params = parse_qs(parsed.query)

    # Parse any params from client request
    client_parsed = urlparse(client_path)
    client_params = parse_qs(client_parsed.query)

    # Merge: client params override, then add defaults
    merged = {**existing_params, **client_params}
    if "text_prompt" not in merged:
        merged["text_prompt"] = [DEFAULT_TEXT_PROMPT]

    new_query = urlencode({k: v[0] for k, v in merged.items()})
    return urlunparse(parsed._replace(query=new_query))


# ── Per-connection handler ─────────────────────────────────────────
async def handle_client(client_ws):
    """Handle one bridge.js connection, proxy to Moshi with Opus transcoding."""
    peer = client_ws.remote_address
    path = client_ws.request.path if hasattr(client_ws, "request") else "/"
    moshi_url = build_moshi_url(path)
    print(f"[+] Client from {peer} -> Moshi at {moshi_url}")

    # Opus encoder/decoder using sphn (same library as Moshi server)
    opus_writer = sphn.OpusStreamWriter(MOSHI_RATE)  # PCM → Opus
    opus_reader = sphn.OpusStreamReader(MOSHI_RATE)   # Opus → PCM

    frame_count = 0
    moshi_frame_count = 0
    debug_transcriber = DebugTranscriber() if TRANSCRIBE_INBOUND_AUDIO else None

    # Connect to Moshi backend
    extra_headers = {}
    if API_KEY:
        extra_headers["x-api-key"] = API_KEY

    try:
        async with websockets.connect(
            moshi_url,
            additional_headers=extra_headers,
            max_size=10 * 1024 * 1024,
        ) as moshi_ws:
            print(f"[moshi] Connected to backend")

            # Gate: client_to_moshi waits until Moshi sends handshake
            handshake_event = asyncio.Event()

            async def client_to_moshi():
                """Bridge → ai_server (raw PCM, no kind bytes) → Moshi (Opus)."""
                nonlocal frame_count
                pcm_msgs = 0
                empty_opus = 0
                silent_frames = 0
                dropped_silence_frames = 0
                silence_gate_logged = False
                inbound_speech = []
                inbound_speech_samples = 0
                transcribe_task = None
                # Buffer incoming PCM while waiting for handshake
                pcm_queue = []

                async def transcribe_snapshot(pcm_snapshot: np.ndarray, reason: str) -> None:
                    if debug_transcriber is None or pcm_snapshot.size == 0:
                        return
                    text = await debug_transcriber.transcribe(pcm_snapshot)
                    duration = len(pcm_snapshot) / BRIDGE_RATE
                    if text:
                        print(f"[asr] bridge->ai ({duration:.2f}s, reason={reason}): {text}")
                    else:
                        print(f"[asr] bridge->ai ({duration:.2f}s, reason={reason}): <no speech>")

                async def flush_transcript(reason: str) -> None:
                    nonlocal inbound_speech, inbound_speech_samples, transcribe_task
                    if debug_transcriber is None or inbound_speech_samples == 0:
                        return
                    if inbound_speech_samples < int(BRIDGE_RATE * TRANSCRIBE_MIN_SECONDS):
                        inbound_speech = []
                        inbound_speech_samples = 0
                        return
                    pcm_snapshot = np.concatenate(inbound_speech).astype(np.float32, copy=False)
                    inbound_speech = []
                    inbound_speech_samples = 0
                    if transcribe_task is not None and not transcribe_task.done():
                        return
                    transcribe_task = asyncio.create_task(transcribe_snapshot(pcm_snapshot, reason))

                async def encode_and_send(raw_pcm: bytes, source: str = "live") -> None:
                    nonlocal frame_count, empty_opus, silent_frames
                    nonlocal dropped_silence_frames, silence_gate_logged
                    nonlocal inbound_speech, inbound_speech_samples

                    log_pcm_frame("bridge->ai.pcm", pcm_msgs, raw_pcm, BRIDGE_RATE)
                    pcm_f32 = pcm16_bytes_to_float32(raw_pcm)
                    rms = pcm_rms(pcm_f32)
                    if debug_transcriber is not None:
                        if rms >= SILENCE_RMS_THRESHOLD:
                            inbound_speech.append(np.ascontiguousarray(pcm_f32, dtype=np.float32))
                            inbound_speech_samples += len(pcm_f32)
                        elif inbound_speech_samples > 0 and (silent_frames + 1) >= TRANSCRIBE_END_SILENT_FRAMES:
                            await flush_transcript("silence")
                    if SILENCE_GATE_ENABLED:
                        if rms < SILENCE_RMS_THRESHOLD:
                            silent_frames += 1
                            if silent_frames > SILENCE_MIN_FRAMES:
                                dropped_silence_frames += 1
                                if not silence_gate_logged:
                                    print(
                                        f"[>] Silence gate active after {SILENCE_MIN_FRAMES} silent frames; "
                                        "dropping idle PCM"
                                    )
                                    silence_gate_logged = True
                                return
                        else:
                            if silence_gate_logged:
                                print(
                                    f"[>] Speech resumed after dropping "
                                    f"{dropped_silence_frames} silent frames"
                                )
                            silent_frames = 0
                            silence_gate_logged = False

                    if BRIDGE_RATE != MOSHI_RATE:
                        pcm_f32 = resample(pcm_f32, BRIDGE_RATE, MOSHI_RATE)
                    opus_writer.append_pcm(np.ascontiguousarray(pcm_f32, dtype=np.float32))
                    opus_bytes = opus_writer.read_bytes()
                    if len(opus_bytes) > 0:
                        await moshi_ws.send(b"\x01" + opus_bytes)
                        frame_count += 1
                        log_binary_frame("ai->moshi.opus", frame_count, opus_bytes)
                        if source == "flush":
                            print(f"[>] #{frame_count} flushed Opus({len(opus_bytes)}B) -> Moshi")
                        elif frame_count <= 5 or frame_count % 500 == 0:
                            print(
                                f"[>] #{frame_count} PCM({len(raw_pcm)}B,{len(pcm_f32)}smp) "
                                f"-> Opus({len(opus_bytes)}B) -> Moshi"
                            )
                    else:
                        empty_opus += 1
                        if empty_opus <= 3:
                            print(f"[>] PCM({len(raw_pcm)}B) -> Opus buffering (no output yet, msg#{pcm_msgs})")

                try:
                    async for message in client_ws:
                        if not isinstance(message, bytes) or len(message) == 0:
                            continue
                        pcm_msgs += 1

                        # Wait for Moshi handshake before sending any audio
                        if not handshake_event.is_set():
                            pcm_queue.append(message)
                            if pcm_msgs <= 3:
                                print(f"[>] Buffering PCM#{pcm_msgs} ({len(message)}B) — waiting for handshake")
                            # Check with short timeout so we keep reading
                            try:
                                await asyncio.wait_for(handshake_event.wait(), timeout=0.001)
                            except asyncio.TimeoutError:
                                continue
                            # Handshake received — flush buffered PCM
                            print(f"[>] Handshake received, flushing {len(pcm_queue)} buffered frames")
                            for buffered in pcm_queue:
                                await encode_and_send(buffered, source="flush")
                            pcm_queue.clear()
                            continue

                        # Normal path: encode and send
                        await encode_and_send(message)
                except websockets.ConnectionClosed:
                    pass
                await flush_transcript("disconnect")
                if transcribe_task is not None:
                    with suppress(Exception):
                        await transcribe_task
                print(
                    f"[>] Done: {pcm_msgs} PCM msgs, {frame_count} Opus frames sent, "
                    f"{empty_opus} buffered, {dropped_silence_frames} dropped by silence gate"
                )

            async def moshi_to_client():
                """Moshi (Opus) → ai_server → Bridge (raw PCM)."""
                nonlocal moshi_frame_count
                moshi_msgs = 0
                kind_counts = {}
                try:
                    async for message in moshi_ws:
                        if not isinstance(message, bytes) or len(message) == 0:
                            continue
                        moshi_msgs += 1
                        kind = message[0]
                        payload = message[1:]
                        kind_counts[kind] = kind_counts.get(kind, 0) + 1

                        if kind == 0x00:
                            # Handshake — signal client_to_moshi to start sending
                            handshake_event.set()
                            print("[<] Handshake from Moshi")
                        elif kind == 0x01 and len(payload) > 0:
                            # Audio: Opus decode → PCM → send raw (no kind byte) to bridge
                            log_binary_frame("moshi->ai.opus", moshi_msgs, payload)
                            opus_reader.append_bytes(payload)
                            pcm_f32 = opus_reader.read_pcm()
                            if pcm_f32 is not None and len(pcm_f32) > 0:
                                if BRIDGE_RATE != MOSHI_RATE:
                                    pcm_f32 = resample(pcm_f32, MOSHI_RATE, BRIDGE_RATE)
                                pcm_bytes = float32_to_pcm16_bytes(pcm_f32)
                                log_pcm_frame("ai->bridge.pcm", moshi_frame_count + 1, pcm_bytes, BRIDGE_RATE)
                                await client_ws.send(pcm_bytes)
                                moshi_frame_count += 1
                                if moshi_frame_count <= 3 or moshi_frame_count % 500 == 0:
                                    print(f"[<] #{moshi_frame_count} Opus({len(payload)}B) -> PCM({len(pcm_bytes)}B) -> Bridge")
                        elif kind == 0x02:
                            # Text token — log only, don't forward to bridge
                            text = payload.decode("utf-8", errors="replace")
                            sys.stdout.write(text)
                            sys.stdout.flush()
                        elif kind == 0x03:
                            # Special token — log only (suppress PAD spam)
                            label = payload.decode("utf-8", errors="replace").strip()
                            if label.upper() not in SUPPRESSED_SPECIAL_TOKENS:
                                print(f"[<] Special: {label}")
                        else:
                            # Unknown kind — log it
                            print(f"[<] Unknown kind={kind} {len(payload)}B")
                except websockets.ConnectionClosed:
                    pass
                print(f"[<] Done: {moshi_msgs} msgs from Moshi, kinds={kind_counts}, {moshi_frame_count} audio to bridge")

            # Run both directions concurrently
            done, pending = await asyncio.wait(
                [
                    asyncio.create_task(client_to_moshi()),
                    asyncio.create_task(moshi_to_client()),
                ],
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()

    except (ConnectionRefusedError, OSError) as e:
        print(f"[moshi] Connection failed: {e}")
        await client_ws.close(1011, "Moshi backend unavailable")
    except Exception as e:
        print(f"[moshi] Error: {e}")

    print(f"[-] Client disconnected (sent={frame_count}, recv={moshi_frame_count} frames)")


# ── Auth + Server ──────────────────────────────────────────────────
async def process_request(path, headers):
    """Check API key auth before upgrading to WebSocket."""
    if not API_KEY:
        return None  # No auth configured

    # Allow health check without auth
    if path == "/health":
        return (200, {}, b'{"status":"ok"}\n')

    key = (
        headers.get("x-api-key", "")
        or headers.get("authorization", "").removeprefix("Bearer ").strip()
    )
    # Also check token query param
    parsed = urlparse(path)
    params = parse_qs(parsed.query)
    token = params.get("token", [""])[0]

    if key == API_KEY or token == API_KEY:
        return None  # Auth OK, proceed with WebSocket
    print(f"[!] Unauthorized request")
    return (401, {}, b"Unauthorized\n")


async def main():
    async with serve(
        handle_client,
        "0.0.0.0",
        PORT,
        process_request=process_request,
        max_size=10 * 1024 * 1024,
    ):
        print(f"Listening on 0.0.0.0:{PORT}")
        stop = asyncio.get_event_loop().create_future()
        await stop  # Run forever


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown.")
