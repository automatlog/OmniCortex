import moshiProcessorUrl from "../../audio-processor.ts?worker&url";
import { FC, useEffect, useState, useCallback, useRef, MutableRefObject } from "react";
import eruda from "eruda";
import { useSearchParams } from "react-router-dom";
import { Conversation } from "../Conversation/Conversation";
import { Button } from "../../components/Button/Button";
import { useModelParams } from "../Conversation/hooks/useModelParams";
import { useLocalStorage } from "../Conversation/hooks/useLocalStorage";
import { env } from "../../env";
import { prewarmDecoderWorker } from "../../decoder/decoderWorker";

const VOICE_OPTIONS = [
  "NATF0.pt", "NATF1.pt", "NATF2.pt", "NATF3.pt",
  "NATM0.pt", "NATM1.pt", "NATM2.pt", "NATM3.pt",
  "VARF0.pt", "VARF1.pt", "VARF2.pt", "VARF3.pt", "VARF4.pt",
  "VARM0.pt", "VARM1.pt", "VARM2.pt", "VARM3.pt", "VARM4.pt",
];

const TEXT_PROMPT_PRESETS = [
  {
    label: "Assistant (default)",
    text: "You are a wise and friendly teacher. Answer questions or provide advice in a clear and engaging way.",
  },
  {
    label: "Medical office (service)",
    text: "You work for Dr. Jones's medical office, and you are receiving calls to record information for new patients. Information: Record full name, date of birth, any medication allergies, tobacco smoking history, alcohol consumption history, and any prior medical conditions. Assure the patient that this information will be confidential, if they ask.",
  },
  {
    label: "Bank (service)",
    text: "You work for First Neuron Bank which is a bank and your name is Alexis Kim. Information: The customer's transaction for $1,200 at Home Depot was declined. Verify customer identity. The transaction was flagged due to unusual location (transaction attempted in Miami, FL; customer normally transacts in Seattle, WA).",
  },
  {
    label: "Astronaut (fun)",
    text: "You enjoy having a good conversation. Have a technical discussion about fixing a reactor core on a spaceship to Mars. You are an astronaut on a Mars mission. Your name is Alex. You are already dealing with a reactor core meltdown on a Mars mission. Several ship systems are failing, and continued instability will lead to catastrophic failure. You explain what is happening and you urgently ask for help thinking through how to stabilize the reactor.",
  },
];

type OmniAgent = {
  id: string;
  name: string;
  type: string;
};

const VOICE_MODES = [
  { value: "personaplex", label: "PersonaPlex", desc: "Full-duplex with Reasoner sidecar" },
  { value: "lfm", label: "LFM 2.5", desc: "LiquidAI interleaved voice model" },
  { value: "cascade", label: "Cascade", desc: "STT \u2192 RAG+LLM \u2192 TTS pipeline" },
] as const;

export type VoiceModeValue = (typeof VOICE_MODES)[number]["value"];

const clampContextQuery = (value: string): string => value.trim().slice(0, 1000);

const parseAgentList = (payload: unknown): OmniAgent[] => {
  const maybeObject = payload as { agents?: unknown };
  const source = Array.isArray(maybeObject?.agents)
    ? maybeObject.agents
    : Array.isArray(payload)
      ? payload
      : [];
  const parsed: OmniAgent[] = [];
  for (const raw of source) {
    if (!raw || typeof raw !== "object") {
      continue;
    }
    const item = raw as Record<string, unknown>;
    const id = String(item.id ?? "").trim();
    if (!id) {
      continue;
    }
    const name = String(item.name ?? item.agent_name ?? id).trim() || id;
    const type = String(item.type ?? item.agent_type ?? item.role_type ?? "agent");
    parsed.push({ id, name, type });
  }
  return parsed;
};

const isLikelyHindi = (text: string): boolean => {
  const normalized = text || "";
  return /[\u0900-\u097F]/.test(normalized) || /\bhindi\b/i.test(normalized);
};

const isPromptFilenameLike = (value: string): boolean => {
  const text = (value || "").trim();
  if (!text || text.includes("\n") || text.includes("\r")) {
    return false;
  }
  const lower = text.toLowerCase();
  const suffixes = [".json", ".txt", ".md", ".yaml", ".yml", ".prompt"];
  return suffixes.some((suffix) => lower.endsWith(suffix)) && text.length <= 180;
};

const resolveCallTriggerConfig = (searchParams: URLSearchParams) => {
  const qpUrl = (searchParams.get("call_trigger_url") || "").trim();
  const qpMethodRaw = (searchParams.get("call_trigger_method") || "").trim().toUpperCase();
  const envUrl = (env.VITE_CALL_TRIGGER_URL || "").trim();
  const envMethod = (env.VITE_CALL_TRIGGER_METHOD || "GET").toUpperCase();

  const url = qpUrl || envUrl;
  const methodRaw = qpMethodRaw || envMethod;
  const method: "GET" | "POST" = methodRaw === "POST" ? "POST" : "GET";
  return { url, method };
};

interface HomepageProps {
  showMicrophoneAccessMessage: boolean;
  startConnection: () => Promise<void>;
  textPrompt: string;
  setTextPrompt: (value: string) => void;
  voicePrompt: string;
  setVoicePrompt: (value: string) => void;
  voiceMode: VoiceModeValue;
  setVoiceMode: (value: VoiceModeValue) => void;
  omniBearer: string;
  setOmniBearer: (value: string) => void;
  omniUserId: string;
  setOmniUserId: (value: string) => void;
  contextQuery: string;
  setContextQuery: (value: string) => void;
  selectedAgentId: string;
  setSelectedAgentId: (value: string) => void;
  agents: OmniAgent[];
  agentsLoading: boolean;
  agentsError: string;
  onRefreshAgents: () => Promise<void>;
  onLoadPrompt: () => Promise<void>;
}

const Homepage = ({
  startConnection,
  showMicrophoneAccessMessage,
  textPrompt,
  setTextPrompt,
  voicePrompt,
  setVoicePrompt,
  voiceMode,
  setVoiceMode,
  omniBearer,
  setOmniBearer,
  omniUserId,
  setOmniUserId,
  contextQuery,
  setContextQuery,
  selectedAgentId,
  setSelectedAgentId,
  agents,
  agentsLoading,
  agentsError,
  onRefreshAgents,
  onLoadPrompt,
}: HomepageProps) => {
  const textPromptIsHindi = isLikelyHindi(textPrompt);
  const selectedAgent = agents.find((agent) => agent.id === selectedAgentId) || null;
  const contextChars = contextQuery.length;

  return (
    <div className="text-center min-h-screen w-screen p-4 flex flex-col items-center pt-8 bg-gradient-to-b from-white to-gray-50">
      <div className="mb-6">
        <h1 className="text-4xl font-bold text-gray-900 tracking-tight">
          <span className="text-[#76b900]">Omni</span>Cortex
        </h1>
        <p className="text-sm text-gray-500 mt-1">PersonaPlex Voice Gateway</p>
        <p className="text-xs text-gray-400 mt-1">
          Full-duplex conversational AI with multi-mode voice pipeline
        </p>
      </div>

      <div className="flex flex-grow justify-center items-center flex-col gap-6 w-full min-w-[500px] max-w-2xl">
        <div className="w-full border border-gray-300 rounded p-4 bg-gray-50 text-left">
          <div className="flex justify-between items-center gap-3 flex-wrap">
            <div>
              <h2 className="text-base font-semibold text-gray-800">OmniCortex Agent</h2>
              <p className="text-xs text-gray-500 mt-1">
                Select one created agent. The same agent_id is used for both text and voice sessions.
              </p>
            </div>
            <Button onClick={onRefreshAgents} disabled={agentsLoading}>
              {agentsLoading ? "Loading Agents..." : "Refresh Agents"}
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
            <div>
              <label htmlFor="omni-bearer" className="block text-xs text-gray-600 mb-1">
                Authorization Bearer (optional if server has key)
              </label>
              <input
                id="omni-bearer"
                value={omniBearer}
                onChange={(e) => setOmniBearer(e.target.value)}
                className="w-full p-2 bg-white text-black border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#76b900]"
                placeholder="Bearer token"
                autoComplete="off"
              />
            </div>
            <div>
              <label htmlFor="omni-user-id" className="block text-xs text-gray-600 mb-1">
                X-User-Id (optional)
              </label>
              <input
                id="omni-user-id"
                value={omniUserId}
                onChange={(e) => setOmniUserId(e.target.value)}
                className="w-full p-2 bg-white text-black border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#76b900]"
                placeholder="User id"
                autoComplete="off"
              />
            </div>
          </div>

          <div className="mt-3">
            <label htmlFor="agent-select" className="block text-xs text-gray-600 mb-1">
              Agent
            </label>
            <select
              id="agent-select"
              value={selectedAgentId}
              onChange={(e) => setSelectedAgentId(e.target.value)}
              className="w-full p-2 bg-white text-black border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#76b900]"
            >
              <option value="">Select an agent</option>
              {agents.map((agent) => (
                <option key={agent.id} value={agent.id}>
                  {agent.name} ({agent.type})
                </option>
              ))}
            </select>
            <p className="text-xs text-gray-500 mt-1">
              {selectedAgent
                ? `Selected: ${selectedAgent.name}`
                : "No agent selected yet. Refresh agents if list is empty."}
            </p>
          </div>

          <div className="mt-3">
            <label htmlFor="context-query" className="block text-xs text-gray-600 mb-1">
              Context Query Seed (max 1000)
            </label>
            <textarea
              id="context-query"
              value={contextQuery}
              onChange={(e) => setContextQuery(clampContextQuery(e.target.value))}
              className="w-full min-h-[70px] p-2 bg-white text-black border border-gray-300 rounded resize-y focus:outline-none focus:ring-2 focus:ring-[#76b900]"
              maxLength={1000}
              placeholder="Optional retrieval seed. If empty, text prompt is used."
            />
            <div className="text-right text-xs text-gray-500 mt-1">{contextChars}/1000</div>
          </div>

          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <Button onClick={onLoadPrompt} disabled={!selectedAgentId}>
              Load Selected Agent Prompt
            </Button>
            {agentsError ? <span className="text-xs text-red-600">{agentsError}</span> : null}
          </div>
        </div>

        <div className="w-full">
          <label htmlFor="text-prompt" className="block text-left text-base font-medium text-gray-700 mb-2">
            Text Prompt:
          </label>
          <div className="border border-gray-300 rounded p-3 mb-3 bg-gray-50">
            <span className="text-xs font-medium text-gray-500 block mb-2">Examples:</span>
            <div className="flex flex-wrap gap-2 justify-center">
              {TEXT_PROMPT_PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  onClick={() => setTextPrompt(preset.text)}
                  className="px-3 py-1 text-xs bg-white hover:bg-gray-100 text-gray-700 rounded-full border border-gray-300 transition-colors focus:outline-none focus:ring-2 focus:ring-[#76b900]"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>
          <textarea
            id="text-prompt"
            name="text-prompt"
            value={textPrompt}
            onChange={(e) => setTextPrompt(e.target.value)}
            className="w-full h-32 min-h-[80px] max-h-64 p-3 bg-white text-black border border-gray-300 rounded resize-y focus:outline-none focus:ring-2 focus:ring-[#76b900] focus:border-transparent"
            placeholder="Enter your text prompt..."
            maxLength={1000}
          />
          <div className="text-right text-xs text-gray-500 mt-1">
            {textPrompt.length}/1000
          </div>
          <p className="text-xs text-gray-600 mt-1">
            Officially optimized for English. For English voices, NATF*/NATM* are recommended.
          </p>
          {textPromptIsHindi ? (
            <p className="text-xs text-amber-700 mt-1">
              Hindi is experimental/unofficial in upstream PersonaPlex.
            </p>
          ) : null}
        </div>

        <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="voice-prompt" className="block text-left text-sm font-medium text-gray-700 mb-2">
              Voice:
            </label>
            <select
              id="voice-prompt"
              name="voice-prompt"
              value={voicePrompt}
              onChange={(e) => setVoicePrompt(e.target.value)}
              className="w-full p-3 bg-white text-black border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#76b900] focus:border-transparent"
            >
              {VOICE_OPTIONS.map((voice) => (
                <option key={voice} value={voice}>
                  {voice
                    .replace(".pt", "")
                    .replace(/^NAT/, "NATURAL_")
                    .replace(/^VAR/, "VARIETY_")}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="voice-mode" className="block text-left text-sm font-medium text-gray-700 mb-2">
              Voice Mode:
            </label>
            <select
              id="voice-mode"
              name="voice-mode"
              value={voiceMode}
              onChange={(e) => setVoiceMode(e.target.value as VoiceModeValue)}
              className="w-full p-3 bg-white text-black border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#76b900] focus:border-transparent"
            >
              {VOICE_MODES.map((mode) => (
                <option key={mode.value} value={mode.value}>
                  {mode.label}
                </option>
              ))}
            </select>
            <p className="text-xs text-gray-500 mt-1 text-left">
              {VOICE_MODES.find((m) => m.value === voiceMode)?.desc}
            </p>
          </div>
        </div>

        {showMicrophoneAccessMessage && (
          <p className="text-center text-red-500">Please enable your microphone before proceeding</p>
        )}

        <Button onClick={async () => await startConnection()}>Connect</Button>
      </div>
    </div>
  );
};

export const Queue: FC = () => {
  const theme = "light" as const;
  const [searchParams] = useSearchParams();
  const overrideWorkerAddr = searchParams.get("worker_addr");
  const [hasMicrophoneAccess, setHasMicrophoneAccess] = useState<boolean>(false);
  const [showMicrophoneAccessMessage, setShowMicrophoneAccessMessage] = useState<boolean>(false);
  const modelParams = useModelParams();

  const [omniBearer, setOmniBearer] = useLocalStorage<string>("omnicortex_bearer_token", "");
  const [omniUserId, setOmniUserId] = useLocalStorage<string>("omnicortex_user_id", "");
  const [selectedAgentId, setSelectedAgentId] = useLocalStorage<string>("omnicortex_selected_agent", "");
  const [contextQuery, setContextQuery] = useLocalStorage<string>("omnicortex_context_query", "");
  const [voiceMode, setVoiceMode] = useLocalStorage<VoiceModeValue>("omnicortex_voice_mode", "personaplex");
  const [agents, setAgents] = useState<OmniAgent[]>([]);
  const [agentsLoading, setAgentsLoading] = useState<boolean>(false);
  const [agentsError, setAgentsError] = useState<string>("");
  const [connectStatus, setConnectStatus] = useState<string>("");

  const audioContext = useRef<AudioContext | null>(null);
  const worklet = useRef<AudioWorkletNode | null>(null);

  useEffect(() => {
    if (env.VITE_ENV === "development") {
      eruda.init();
    }
    return () => {
      if (env.VITE_ENV === "development") {
        eruda.destroy();
      }
    };
  }, []);

  const fetchAgents = useCallback(async () => {
    setAgentsLoading(true);
    setAgentsError("");
    try {
      const endpoint = new URL("/api/agents", window.location.origin);
      if (omniBearer.trim()) {
        endpoint.searchParams.set("omni_bearer", omniBearer.trim());
      }
      if (omniUserId.trim()) {
        endpoint.searchParams.set("omni_user_id", omniUserId.trim());
      }

      const response = await fetch(endpoint.toString(), { cache: "no-store" });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        const detail = typeof payload?.error === "string" ? payload.error : `Failed to load agents (${response.status})`;
        throw new Error(detail);
      }

      const list = parseAgentList(payload);
      setAgents(list);
      setSelectedAgentId((current) => (
        current && !list.some((agent) => agent.id === current) ? "" : current
      ));
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setAgents([]);
      setAgentsError(message);
    } finally {
      setAgentsLoading(false);
    }
  }, [omniBearer, omniUserId, setSelectedAgentId]);

  const loadSelectedPrompt = useCallback(async () => {
    if (!selectedAgentId) {
      return;
    }
    try {
      setAgentsError("");
      const endpoint = new URL("/api/agent-prompt", window.location.origin);
      endpoint.searchParams.set("agent_id", selectedAgentId);
      const promptFallback = modelParams.textPrompt || "";
      const seedBase = contextQuery || (isPromptFilenameLike(promptFallback) ? "" : promptFallback);
      const seed = clampContextQuery(seedBase);
      if (seed) {
        endpoint.searchParams.set("context_query", seed);
      }
      if (omniBearer.trim()) {
        endpoint.searchParams.set("omni_bearer", omniBearer.trim());
      }
      if (omniUserId.trim()) {
        endpoint.searchParams.set("omni_user_id", omniUserId.trim());
      }
      const response = await fetch(endpoint.toString(), { cache: "no-store" });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        const detail = typeof payload?.error === "string" ? payload.error : `Failed to load agent prompt (${response.status})`;
        throw new Error(detail);
      }
      const prompt = typeof payload?.prompt === "string" ? payload.prompt.trim() : "";
      if (prompt) {
        modelParams.setTextPrompt(prompt.slice(0, 1000));
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setAgentsError(message);
    }
  }, [
    contextQuery,
    modelParams,
    omniBearer,
    omniUserId,
    selectedAgentId,
  ]);

  useEffect(() => {
    void fetchAgents();
  }, [fetchAgents]);

  const getMicrophoneAccess = useCallback(async () => {
    try {
      await window.navigator.mediaDevices.getUserMedia({ audio: true });
      setHasMicrophoneAccess(true);
      return true;
    } catch (error) {
      console.error(error);
      setShowMicrophoneAccessMessage(true);
      setHasMicrophoneAccess(false);
    }
    return false;
  }, []);

  const startProcessor = useCallback(async () => {
    if (!audioContext.current) {
      audioContext.current = new AudioContext();
      prewarmDecoderWorker(audioContext.current.sampleRate);
    }
    if (worklet.current) {
      return;
    }
    const ctx = audioContext.current;
    ctx.resume();
    try {
      worklet.current = new AudioWorkletNode(ctx, "moshi-processor");
    } catch (_error) {
      await ctx.audioWorklet.addModule(moshiProcessorUrl);
      worklet.current = new AudioWorkletNode(ctx, "moshi-processor");
    }
    worklet.current.connect(ctx.destination);
  }, []);

  const startConnection = useCallback(async () => {
    setConnectStatus("");
    const trigger = resolveCallTriggerConfig(searchParams);
    try {
      const hasExplicitTrigger = Boolean(trigger.url);
      const endpoint = hasExplicitTrigger ? "/api/call-trigger" : "/trigger-call";
      const requestInit = hasExplicitTrigger
        ? {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: trigger.url, method: trigger.method }),
          }
        : { method: "GET" };
      let response = await fetch(endpoint, requestInit);
      if (response.status === 404) {
        const fallbackEndpoint = endpoint === "/api/call-trigger" ? "/trigger-call" : "/api/call-trigger";
        response = await fetch(
          fallbackEndpoint,
          hasExplicitTrigger
            ? {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ url: trigger.url, method: trigger.method }),
              }
            : { method: "GET" },
        );
      }
      const payload = await response.json().catch(() => ({}));
      const statusText = String(payload?.status || "").toLowerCase();
      const message = String(payload?.message || "").trim();
      const isNotConfigured =
        response.status === 400 && message.toLowerCase().includes("not configured");
      const isOptionalMissingRoute = !hasExplicitTrigger && response.status === 404;

      if ((isNotConfigured && !hasExplicitTrigger) || isOptionalMissingRoute) {
        // Optional default trigger isn't configured on server; continue without surfacing an error.
      } else if (!response.ok || statusText === "error") {
        const detail = message || `Call trigger failed (${response.status})`;
        setConnectStatus(`Call trigger error: ${detail}`);
      } else {
        setConnectStatus("Call triggered successfully.");
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setConnectStatus(`Call trigger error: ${message}`);
    }
    await startProcessor();
    await getMicrophoneAccess();
  }, [getMicrophoneAccess, searchParams, startProcessor]);

  const promptFallback = modelParams.textPrompt || "";
  const effectiveContextQuery = clampContextQuery(
    contextQuery || (isPromptFilenameLike(promptFallback) ? "" : promptFallback)
  );

  return (
    <>
      {(hasMicrophoneAccess && audioContext.current && worklet.current) ? (
        <Conversation
          workerAddr={overrideWorkerAddr ?? ""}
          audioContext={audioContext as MutableRefObject<AudioContext | null>}
          worklet={worklet as MutableRefObject<AudioWorkletNode | null>}
          theme={theme}
          startConnection={startConnection}
          agentId={selectedAgentId || undefined}
          contextQuery={effectiveContextQuery || undefined}
          omniBearer={omniBearer.trim() || undefined}
          omniUserId={omniUserId.trim() || undefined}
          voiceMode={voiceMode}
          {...modelParams}
        />
      ) : (
        <Homepage
          startConnection={startConnection}
          showMicrophoneAccessMessage={showMicrophoneAccessMessage}
          textPrompt={modelParams.textPrompt}
          setTextPrompt={modelParams.setTextPrompt}
          voicePrompt={modelParams.voicePrompt}
          setVoicePrompt={modelParams.setVoicePrompt}
          voiceMode={voiceMode}
          setVoiceMode={setVoiceMode}
          omniBearer={omniBearer}
          setOmniBearer={setOmniBearer}
          omniUserId={omniUserId}
          setOmniUserId={setOmniUserId}
          contextQuery={contextQuery}
          setContextQuery={setContextQuery}
          selectedAgentId={selectedAgentId}
          setSelectedAgentId={setSelectedAgentId}
          agents={agents}
          agentsLoading={agentsLoading}
          agentsError={agentsError}
          onRefreshAgents={fetchAgents}
          onLoadPrompt={loadSelectedPrompt}
        />
      )}
      {connectStatus ? (
        <div className="fixed bottom-3 right-3 bg-white text-gray-800 border border-gray-300 rounded px-3 py-2 text-xs shadow">
          {connectStatus}
        </div>
      ) : null}
    </>
  );
};
