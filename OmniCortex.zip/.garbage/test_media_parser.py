
import sys
import os

# Add project root to path
sys.path.append(os.getcwd())

from core.response_parser import parse_response, process_rich_response_for_frontend

# Mock Agent Data for Resolution
MOCK_AGENT = {
    "image_urls": ["https://example.com/sunset.jpg", "https://example.com/pizza.png"],
    "video_urls": ["https://example.com/demo.mp4"]
}

# Mock get_agent to return our data
import core.response_parser
original_get_agent = core.response_parser.get_agent
core.response_parser.get_agent = lambda id: MOCK_AGENT

# Mock _resolve_document_url
core.response_parser._resolve_document_url = lambda filename, agent_id: f"/api/documents/mock/{filename}"

def test_parser():
    print("🧪 Testing Response Parser...")
    
    # 1. Mixed Content
    text = """Here is a photo: [image][sunset.jpg]
    And a video: [video][demo.mp4]
    Also check this doc: [document][menu.pdf]
    """
    
    parts = parse_response(text, agent_id="mock_id")
    print(f"\nInput:\n{text}")
    print("Parsed Parts:")
    for p in parts:
        print(f"  - {p}")

    # Validate
    assert any(p['type'] == 'image' and p['url'] == "https://example.com/sunset.jpg" for p in parts)
    assert any(p['type'] == 'video' and p['url'] == "https://example.com/demo.mp4" for p in parts)
    assert any(p['type'] == 'document' and p['filename'] == "menu.pdf" for p in parts)


def test_frontend_formatter():
    print("\n🧪 Testing Frontend Formatter...")
    
    text = """
    Check [image][sunset.jpg]
    Watch [video][demo.mp4]
    [buttons][Title][Opt1|Opt2]
    """
    
    formatted = process_rich_response_for_frontend(text, agent_id="mock_id")
    print(f"\nInput:\n{text}")
    print(f"Formatted:\n{formatted}")
    
    assert "![sunset.jpg](https://example.com/sunset.jpg)" in formatted
    assert "[Video: demo.mp4](https://example.com/demo.mp4)" in formatted
    assert "**Title**" in formatted

if __name__ == "__main__":
    try:
        test_parser()
        test_frontend_formatter()
        print("\n✅ All Tests Passed!")
    except Exception as e:
        print(f"\n❌ Test Failed: {e}")
        import traceback
        traceback.print_exc()
