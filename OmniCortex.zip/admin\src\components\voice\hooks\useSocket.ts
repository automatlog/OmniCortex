import { useState, useEffect, useCallback, useRef } from "react";
import { WSMessage, SocketStatus } from "@/lib/voice/protocol/types";
import { decodeMessage, encodeMessage } from "@/lib/voice/protocol/encoder";

export const useSocket = ({
  onMessage,
  uri,
  onDisconnect: onDisconnectProp,
}: {
  onMessage?: (message: WSMessage) => void;
  uri: string;
  onDisconnect?: () => void;
}) => {
  const lastMessageTime = useRef<null|number>(null);
  const socketRef = useRef<WebSocket | null>(null); // useRef to keep stable socket reference
  const [socketStatus, setSocketStatus] = useState<SocketStatus>("disconnected");
  // Disable inactivity auto-close by default. Set NEXT_PUBLIC_VOICE_SOCKET_INACTIVITY_MS
  // to a positive value (e.g. 60000) only if you explicitly want it.
  const inactivityTimeoutMs = Number(
    process.env.NEXT_PUBLIC_VOICE_SOCKET_INACTIVITY_MS || "0",
  );

  const sendMessage = useCallback(
    (message: WSMessage) => {
      if (!socketRef.current || socketStatus !== "connected") {
        console.log("socket not connected");
        return;
      }
      socketRef.current.send(encodeMessage(message));
    },
    [socketRef, socketStatus],
  );

  const onConnect = useCallback(() => {
    console.log("connected, now waiting for handshake.");
    setSocketStatus("connecting");
  }, [setSocketStatus]);

  const onDisconnect = useCallback((event: CloseEvent) => {
    const closedSocket = event.target as WebSocket;
    console.log("disconnected");
    setSocketStatus("disconnected");
    // ONLY clear socketRef.current if it's the one that closed
    if (socketRef.current === closedSocket) {
      console.log("disconnected (current socket)");
      socketRef.current = null;
      setSocketStatus("disconnected");
      onDisconnectProp?.();
    } else {
      console.log("disconnected (stale socket ignored)");
    }
  }, [onDisconnectProp]);

  const onMessageEvent = useCallback(
    (eventData: MessageEvent) => {
      lastMessageTime.current = Date.now();
      const dataArray = new Uint8Array(eventData.data);
      const message = decodeMessage(dataArray);
      if (message.type == "handshake") {
        console.log("Handshake received, let's rocknroll.");
        setSocketStatus("connected");
      }
      if (!onMessage) {
        return;
      }
      onMessage(message);
    },
    [onMessage, setSocketStatus],
  );

  const start = useCallback(() => {
    // Close existing socket if any
    if (socketRef.current) {
      console.log("closing existing socket before creating new one");
      socketRef.current.close();
    }
    const ws = new WebSocket(uri);
    ws.binaryType = "arraybuffer";
    ws.addEventListener("open", onConnect);
    ws.addEventListener("close", onDisconnect);
    ws.addEventListener("message", onMessageEvent);

    socketRef.current = ws;
    lastMessageTime.current = Date.now();
    console.log("Socket created", ws);
  }, [uri, onMessage, onConnect, onDisconnect, onMessageEvent]);

  const stop = useCallback(() => {
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
      setSocketStatus("disconnected");
      // if (onDisconnectProp) {
      //   onDisconnectProp();
      // }
      // socket?.close();
      // setSocket(null);
  }, []);

  useEffect(() => {
    if (socketStatus !== "connected" || !(inactivityTimeoutMs > 0)) {
      return;
    }
    const intervalId = setInterval(() => {
      if (
        lastMessageTime.current &&
        Date.now() - lastMessageTime.current > inactivityTimeoutMs
      ) {
        console.log("closing socket due to inactivity", socketRef.current);
        socketRef.current?.close();
      }
    }, 500);

    return () => {
      clearInterval(intervalId);
    };
  }, [socketStatus, inactivityTimeoutMs]);

  return {
    socketStatus,
    socket: socketRef.current,
    sendMessage,
    start,
    stop,
    setSocketStatus,
  };
};
