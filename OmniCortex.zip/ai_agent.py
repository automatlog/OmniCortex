import asyncio
import base64
import json
import http
import os
from contextlib import asynccontextmanager
from urllib.parse import urlencode

import aiohttp
import numpy as np
import websockets
from dotenv import load_dotenv

load_dotenv()

try:
    import torch
    import torchaudio.transforms as T
except Exception:  # pragma: no cover - fallback path
    torch = None
    T = None


HOST = str(os.getenv("AI_AGENT_HOST", "0.0.0.0")).strip()
PORT = int(os.getenv("AI_AGENT_PORT", "14496"))
UPSTREAM_CONNECT_TIMEOUT_S = float(os.getenv("AI_UPSTREAM_CONNECT_TIMEOUT_S", "20"))

# ElevenLabs streaming STT websocket (binary gateway path).
ELEVENLABS_API_KEY = str(os.getenv("ELEVENLABS_API_KEY", "")).strip()
ELEVENLABS_STT_WS_URL = str(
    os.getenv(
        "ELEVENLABS_STT_WS_URL",
        "wss://api.elevenlabs.io/v1/speech-to-text/audio-provider-streaming",
    )
).strip()
ELEVENLABS_STT_LANGUAGE = str(os.getenv("ELEVENLABS_STT_LANGUAGE", "en")).strip()
ELEVENLABS_STT_RATE = int(os.getenv("ELEVENLABS_STT_RATE", "16000"))

# ElevenLabs realtime STT (JSON bridge/FreeSWITCH path).
ELEVENLABS_STT_REALTIME_WS_URL = str(
    os.getenv(
        "ELEVENLABS_STT_REALTIME_WS_URL",
        "wss://api.elevenlabs.io/v1/speech-to-text/realtime",
    )
).strip()
ELEVENLABS_STT_REALTIME_MODEL_ID = str(
    os.getenv("ELEVENLABS_STT_REALTIME_MODEL_ID", "scribe_v2_realtime")
).strip()
ELEVENLABS_STT_COMMIT_STRATEGY = str(os.getenv("ELEVENLABS_STT_COMMIT_STRATEGY", "vad")).strip()

# ElevenLabs TTS (for streaming audio back to FreeSWITCH).
ELEVENLABS_BASE_URL = str(os.getenv("ELEVENLABS_BASE_URL", "https://api.elevenlabs.io")).strip().rstrip("/")
ELEVENLABS_VOICE_ID = str(os.getenv("ELEVENLABS_VOICE_ID", "EXAVITQu4vr4xnSDxMaL")).strip()
ELEVENLABS_TTS_MODEL_ID = str(os.getenv("ELEVENLABS_TTS_MODEL_ID", "eleven_turbo_v2_5")).strip()
ELEVENLABS_TTS_TIMEOUT_S = float(os.getenv("ELEVENLABS_TTS_TIMEOUT_S", "30"))

# api.py /query endpoint for full RAG (JSON bridge path).
API_QUERY_URL = str(os.getenv("API_QUERY_URL", "http://127.0.0.1:8000/query")).strip()
API_AGENT_ID = str(os.getenv("API_AGENT_ID", "")).strip()
API_BEARER_TOKEN = str(os.getenv("API_BEARER_TOKEN", "")).strip()
API_QUERY_TIMEOUT_S = float(os.getenv("API_QUERY_TIMEOUT_S", "30"))

# Optional direct vLLM reply (binary gateway path).
AI_USE_VLLM_REPLY = str(os.getenv("AI_USE_VLLM_REPLY", "true")).strip().lower() == "true"
VLLM_URL = str(os.getenv("VLLM_URL", "http://127.0.0.1:8000/v1/chat/completions")).strip()
VLLM_MODEL = str(os.getenv("VLLM_MODEL", "llama3.1:8b")).strip()
VLLM_TIMEOUT_S = float(os.getenv("VLLM_TIMEOUT_S", "15"))

# Audio rates.
GATEWAY_RATE = int(os.getenv("AI_GATEWAY_SAMPLE_RATE", "8000"))
TTS_CHUNK_MS = int(os.getenv("TTS_CHUNK_MS", "20"))

LOG_TEXT = str(os.getenv("AI_LOG_TEXT_FRAMES", "true")).strip().lower() == "true"
LOG_AUDIO = str(os.getenv("AI_LOG_AUDIO_FRAMES", "true")).strip().lower() == "true"

# Greeting cache: skip API for common greetings, respond instantly.
GREETING_CACHE = {
    "hello": "Hi! How can I assist you?",
    "hi": "Hi! How can I assist you?",
    "hey": "Hey! How can I assist you?",
    "okay": "How can I help you?",
    "good morning": "Good morning! How can I assist you?",
    "good afternoon": "Good afternoon! How can I assist you?",
    "good evening": "Good evening! How can I assist you?",
    "namaste": "Namaste! How can I assist you?",
}


def _check_greeting_cache(text: str) -> str | None:
    """Return cached response for greetings, or None."""
    normalized = text.strip().lower().rstrip(".!?,")
    return GREETING_CACHE.get(normalized)


# ---------------------------------------------------------------------------
# URL builders
# ---------------------------------------------------------------------------

def _build_elevenlabs_stt_url() -> str:
    separator = "&" if "?" in ELEVENLABS_STT_WS_URL else "?"
    return f"{ELEVENLABS_STT_WS_URL}{separator}language={ELEVENLABS_STT_LANGUAGE}"


def _build_elevenlabs_realtime_stt_url() -> str:
    params = {
        "model_id": ELEVENLABS_STT_REALTIME_MODEL_ID,
        "language_code": ELEVENLABS_STT_LANGUAGE,
        "audio_format": f"pcm_{ELEVENLABS_STT_RATE}",
        "commit_strategy": ELEVENLABS_STT_COMMIT_STRATEGY,
    }
    return f"{ELEVENLABS_STT_REALTIME_WS_URL}?{urlencode(params)}"


# ---------------------------------------------------------------------------
# WebSocket helpers
# ---------------------------------------------------------------------------

@asynccontextmanager
async def _connect_ws_with_headers(url: str, headers: dict[str, str]):
    # websockets API differs across versions: additional_headers vs extra_headers.
    try:
        async with websockets.connect(
            url,
            additional_headers=headers,
            open_timeout=UPSTREAM_CONNECT_TIMEOUT_S,
            ping_interval=20,
            ping_timeout=20,
            max_size=8 * 1024 * 1024,
        ) as ws:
            yield ws
        return
    except TypeError:
        pass

    async with websockets.connect(
        url,
        extra_headers=headers,
        open_timeout=UPSTREAM_CONNECT_TIMEOUT_S,
        ping_interval=20,
        ping_timeout=20,
        max_size=8 * 1024 * 1024,
    ) as ws:
        yield ws


# ---------------------------------------------------------------------------
# STT transcript extraction (unified for both endpoints)
# ---------------------------------------------------------------------------

def _extract_stt_transcript(payload: dict) -> tuple[str, bool]:
    """Extract transcript from ElevenLabs STT event.

    Returns (text, is_final). Handles both audio-provider-streaming
    and realtime endpoint formats.
    """
    text = (
        payload.get("text")
        or payload.get("transcript")
        or (payload.get("data") or {}).get("text")
        or ""
    )
    text = str(text).strip()
    if not text:
        return "", False

    # Realtime endpoint format
    message_type = str(payload.get("message_type") or "").lower()
    if message_type in {
        "committed_transcript",
        "committed_transcript_with_timestamps",
    }:
        return text, True
    if message_type == "partial_transcript":
        return text, False

    # Audio-provider-streaming endpoint format
    event_type = str(payload.get("type") or "").lower()
    status = str(payload.get("status") or "").lower()

    if bool(payload.get("is_final")):
        return text, True
    if event_type in {"final", "speech_final", "transcript_final"}:
        return text, True
    if event_type == "status" and status in {"finished", "final"}:
        return text, True

    return text, False


# ---------------------------------------------------------------------------
# LLM / API backends
# ---------------------------------------------------------------------------

async def _call_vllm_local(session: aiohttp.ClientSession, user_text: str) -> str:
    body = {
        "model": VLLM_MODEL,
        "messages": [{"role": "user", "content": user_text}],
        "temperature": 0.7,
        "max_tokens": 150,
    }
    try:
        async with session.post(VLLM_URL, json=body) as resp:
            if resp.status != 200:
                response_text = await resp.text()
                return f"vLLM error ({resp.status}): {response_text[:180]}"
            data = await resp.json()
            message = ((data.get("choices") or [{}])[0] or {}).get("message") or {}
            content = str(message.get("content") or "").strip()
            return content or "vLLM returned empty response."
    except asyncio.TimeoutError:
        return "vLLM timeout."
    except Exception as exc:
        return f"vLLM connection failed: {exc}"


async def _call_api_query(
    session: aiohttp.ClientSession,
    user_text: str,
    bearer: str = "",
    user_id: str = "",
    agent_id: str = "",
) -> str:
    """Call api.py /query endpoint for full RAG pipeline."""
    resolved_agent_id = agent_id or API_AGENT_ID
    resolved_bearer = bearer or API_BEARER_TOKEN
    body = {
        "question": f"{user_text} (Respond in English only)",
        "id": resolved_agent_id,
        "user_id": user_id or "voice_user",
        "channel_name": "VOICE",
    }
    headers = {"Content-Type": "application/json"}
    if resolved_bearer:
        headers["Authorization"] = f"Bearer {resolved_bearer}"

    try:
        async with session.post(API_QUERY_URL, json=body, headers=headers) as resp:
            if resp.status != 200:
                response_text = await resp.text()
                return f"API error ({resp.status}): {response_text[:200]}"
            data = await resp.json()
            answer = str(data.get("answer") or "").strip()
            return answer or "API returned empty response."
    except asyncio.TimeoutError:
        return "API query timeout."
    except Exception as exc:
        return f"API query failed: {exc}"


# ---------------------------------------------------------------------------
# ElevenLabs TTS
# ---------------------------------------------------------------------------

async def _call_elevenlabs_tts(session: aiohttp.ClientSession, text: str) -> bytes:
    """Call ElevenLabs TTS HTTP API. Returns raw PCM 16kHz bytes."""
    if not text.strip():
        return b""
    url = f"{ELEVENLABS_BASE_URL}/v1/text-to-speech/{ELEVENLABS_VOICE_ID}"
    headers = {
        "xi-api-key": ELEVENLABS_API_KEY,
        "Content-Type": "application/json",
    }
    body = {
        "text": text,
        "model_id": ELEVENLABS_TTS_MODEL_ID,
    }
    params = {"output_format": "pcm_16000"}

    try:
        async with session.post(url, json=body, headers=headers, params=params) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                print(f"[tts] ElevenLabs error ({resp.status}): {error_text[:200]}")
                return b""
            audio_bytes = await resp.read()
            if not audio_bytes:
                print("[tts] ElevenLabs returned empty audio")
                return b""
            print(f"[tts] Got {len(audio_bytes)} bytes PCM 16kHz from ElevenLabs")
            return audio_bytes
    except Exception as exc:
        print(f"[tts] ElevenLabs TTS failed: {exc}")
        return b""


async def _tts_and_stream_back(
    client_ws,
    session: aiohttp.ClientSession,
    ai_text: str,
    tts_resampler: "Resampler",
) -> None:
    """Convert AI text to speech and stream PCM 8kHz chunks back to bridge."""
    pcm_16k = await _call_elevenlabs_tts(session, ai_text)
    if not pcm_16k:
        print(f"[tts] No audio from ElevenLabs for: {ai_text[:80]}")
        return

    print(f"[tts] Got {len(pcm_16k)} bytes PCM 16kHz, resampling to 8kHz...")

    # Resample 16kHz -> 8kHz for FreeSWITCH
    pcm_float = _pcm16_bytes_to_float32(pcm_16k)
    pcm_8k_float = tts_resampler.run(pcm_float)
    pcm_8k_bytes = _float32_to_pcm16_bytes(pcm_8k_float)

    if not pcm_8k_bytes:
        print("[tts] Resampled audio is empty")
        return

    # Send in larger chunks (~200ms each = 3200 bytes at 8kHz 16-bit mono)
    # Bridge sends raw PCM to FreeSWITCH which buffers it, so no need for
    # tiny 20ms frames with sleep between each.
    chunk_size = GATEWAY_RATE * 2 // 5  # 3200 bytes = 200ms at 8kHz
    total_chunks = 0
    for i in range(0, len(pcm_8k_bytes), chunk_size):
        chunk = pcm_8k_bytes[i : i + chunk_size]
        audio_b64 = base64.b64encode(chunk).decode("ascii")
        await client_ws.send(json.dumps({
            "type": "tts_audio",
            "audio": audio_b64,
        }))
        total_chunks += 1
        # Yield to event loop between chunks
        await asyncio.sleep(0)

    await client_ws.send(json.dumps({"type": "tts_done"}))
    duration_s = len(pcm_8k_bytes) / (GATEWAY_RATE * 2)
    print(f"[tts] Streamed {total_chunks} chunks ({len(pcm_8k_bytes)} bytes, {duration_s:.1f}s audio) to bridge")


# ---------------------------------------------------------------------------
# Audio utilities
# ---------------------------------------------------------------------------

class Resampler:
    def __init__(self, src_rate: int, dst_rate: int):
        self.src_rate = src_rate
        self.dst_rate = dst_rate
        self._resampler = None

        if src_rate == dst_rate:
            return
        if torch is not None and T is not None:
            self._resampler = T.Resample(src_rate, dst_rate)

    def run(self, pcm: np.ndarray) -> np.ndarray:
        if pcm.size == 0 or self.src_rate == self.dst_rate:
            return pcm.astype(np.float32, copy=False)
        if self._resampler is not None and torch is not None:
            tensor = torch.from_numpy(pcm.astype(np.float32, copy=False)).unsqueeze(0)
            out = self._resampler(tensor).squeeze(0).detach().cpu().numpy()
            return out.astype(np.float32, copy=False)

        # Numpy fallback: linear interpolation.
        in_len = pcm.shape[0]
        out_len = int(round(in_len * self.dst_rate / self.src_rate))
        if out_len <= 1 or in_len <= 1:
            return pcm.astype(np.float32, copy=False)
        x_old = np.linspace(0.0, 1.0, num=in_len, dtype=np.float64)
        x_new = np.linspace(0.0, 1.0, num=out_len, dtype=np.float64)
        out = np.interp(x_new, x_old, pcm.astype(np.float64))
        return out.astype(np.float32)


def _pcm16_bytes_to_float32(audio_bytes: bytes) -> np.ndarray:
    int16_audio = np.frombuffer(audio_bytes, dtype=np.int16)
    if int16_audio.size == 0:
        return np.zeros((0,), dtype=np.float32)
    return (int16_audio.astype(np.float32) / 32768.0).astype(np.float32)


def _float32_to_pcm16_bytes(audio: np.ndarray) -> bytes:
    if audio.size == 0:
        return b""
    clipped = np.clip(audio, -1.0, 1.0)
    return (clipped * 32767.0).astype(np.int16).tobytes()


# ---------------------------------------------------------------------------
# Binary gateway protocol helpers (existing)
# ---------------------------------------------------------------------------

def _decode_ws_audio_payload(message: bytes) -> bytes:
    """
    Accept both:
    - Admin protocol frame: [0x01][audio bytes...]
    - Raw PCM bytes from non-admin clients
    """
    if not message:
        return b""
    frame_type = message[0]
    if frame_type == 0x01:
        return message[1:]
    if frame_type in {0x00, 0x02, 0x03, 0x04, 0x05, 0x06}:
        return b""
    return message


def _encode_ws_handshake() -> bytes:
    # [type=0x00][version=0][model=0]
    return bytes((0x00, 0x00, 0x00))


def _encode_ws_text(text: str) -> bytes:
    return bytes((0x02,)) + text.encode("utf-8", errors="ignore")


def _encode_ws_error(text: str) -> bytes:
    return bytes((0x05,)) + text.encode("utf-8", errors="ignore")


# ---------------------------------------------------------------------------
# HTTP health check
# ---------------------------------------------------------------------------

async def process_request(connection, request):
    upgrade = str(request.headers.get("Upgrade", "")).lower()
    if upgrade != "websocket":
        return connection.respond(http.HTTPStatus.OK, "OK - AI gateway bridge running")
    return None


# ---------------------------------------------------------------------------
# Handler 1: Binary gateway protocol (existing path)
# ---------------------------------------------------------------------------

async def bridge_call_elevenlabs(client_ws):
    if not ELEVENLABS_API_KEY:
        print("[elevenlabs] missing ELEVENLABS_API_KEY")
        await client_ws.close(code=1011, reason="Missing ELEVENLABS_API_KEY")
        return

    stt_url = _build_elevenlabs_stt_url()
    print(f"[elevenlabs] Connected from gateway, stt_url={stt_url}")

    to_stt_resampler = Resampler(GATEWAY_RATE, ELEVENLABS_STT_RATE)
    http_timeout = aiohttp.ClientTimeout(total=VLLM_TIMEOUT_S)

    try:
        async with (
            _connect_ws_with_headers(stt_url, {"xi-api-key": ELEVENLABS_API_KEY}) as stt_ws,
            aiohttp.ClientSession(timeout=http_timeout) as http_session,
        ):
            print("[elevenlabs] STT websocket connected")
            await client_ws.send(_encode_ws_handshake())
            gw_audio_frames_in = 0
            text_events_out = 0

            async def to_stt():
                nonlocal gw_audio_frames_in
                async for message in client_ws:
                    if not isinstance(message, (bytes, bytearray)):
                        if LOG_TEXT:
                            text = str(message)
                            preview = text[:120].replace("\n", " ")
                            print(f"[gw->stt] text len={len(text)} preview='{preview}'")
                        continue

                    payload = bytes(message)
                    audio_payload = _decode_ws_audio_payload(payload)
                    if not audio_payload:
                        continue
                    gw_audio_frames_in += 1
                    if LOG_AUDIO:
                        print(f"[gw->stt] pcm bytes={len(audio_payload)} frame={gw_audio_frames_in}")

                    pcm_gateway = _pcm16_bytes_to_float32(audio_payload)
                    pcm_stt = to_stt_resampler.run(pcm_gateway)
                    stt_bytes = _float32_to_pcm16_bytes(pcm_stt)
                    if stt_bytes:
                        await stt_ws.send(stt_bytes)

            async def from_stt():
                nonlocal text_events_out
                async for message in stt_ws:
                    if not isinstance(message, str):
                        continue
                    try:
                        payload = json.loads(message)
                    except json.JSONDecodeError:
                        if LOG_TEXT:
                            print(f"[stt->gw] non-json: {message[:120]}")
                        continue

                    transcript, is_final = _extract_stt_transcript(payload)
                    if not transcript or not is_final:
                        continue

                    print(f"[stt] final: {transcript}")
                    out_payload = {
                        "type": "stt_final",
                        "text": transcript,
                    }
                    if AI_USE_VLLM_REPLY:
                        ai_text = await _call_vllm_local(http_session, transcript)
                        out_payload["ai_reply"] = ai_text
                        print(f"[ai-reply] {ai_text}")

                    message_text = out_payload["text"]
                    if out_payload.get("ai_reply"):
                        message_text = f"{message_text}\nAI: {out_payload['ai_reply']}"
                    await client_ws.send(_encode_ws_text(message_text))
                    text_events_out += 1

            tasks = [
                asyncio.create_task(to_stt()),
                asyncio.create_task(from_stt()),
            ]
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            for task in done:
                exc = task.exception()
                if exc:
                    print(f"[elevenlabs] task error: {type(exc).__name__}: {exc}")
            print(f"[elevenlabs] stats gw_in={gw_audio_frames_in} text_out={text_events_out}")

    except websockets.exceptions.InvalidStatusCode as exc:
        print(f"[elevenlabs] handshake failed HTTP {exc.status_code}. Check API key/credits.")
        await client_ws.send(_encode_ws_error(f"ElevenLabs handshake failed HTTP {exc.status_code}."))
    except websockets.exceptions.ConnectionClosed:
        print("[elevenlabs] Connection closed")
    except Exception as error:
        print(f"[elevenlabs] Bridge error: {error}")
        await client_ws.send(_encode_ws_error(str(error)))


# ---------------------------------------------------------------------------
# Handler 2: JSON bridge protocol (FreeSWITCH via fast_ai_bridge.py)
# ---------------------------------------------------------------------------

async def bridge_call_json(client_ws):
    """Handle JSON-protocol connections from fast_ai_bridge.py.

    Audio flow: bridge -> base64 PCM 8kHz -> decode -> resample 8k->16k -> ElevenLabs STT
    Text flow:  STT transcript -> api.py /query (RAG) -> AI text
    TTS flow:   AI text -> ElevenLabs TTS -> PCM 16k -> resample 16k->8k -> base64 -> bridge
    """
    if not ELEVENLABS_API_KEY:
        await client_ws.send(json.dumps({"type": "error", "detail": "Missing ELEVENLABS_API_KEY"}))
        await client_ws.close(code=1011, reason="Missing ELEVENLABS_API_KEY")
        return

    stt_url = _build_elevenlabs_realtime_stt_url()
    print(f"[json-bridge] New connection, stt_url={stt_url}")

    to_stt_resampler = Resampler(GATEWAY_RATE, ELEVENLABS_STT_RATE)
    tts_resampler = Resampler(ELEVENLABS_STT_RATE, GATEWAY_RATE)  # 16k -> 8k
    http_timeout = aiohttp.ClientTimeout(total=max(API_QUERY_TIMEOUT_S, ELEVENLABS_TTS_TIMEOUT_S))

    # Auth context (can be updated by control messages from bridge)
    omni_bearer = API_BEARER_TOKEN
    omni_user_id = "voice_user"
    omni_agent_id = API_AGENT_ID

    try:
        async with (
            _connect_ws_with_headers(stt_url, {"xi-api-key": ELEVENLABS_API_KEY}) as stt_ws,
            aiohttp.ClientSession(timeout=http_timeout) as http_session,
        ):
            print("[json-bridge] ElevenLabs STT connected")
            await client_ws.send(json.dumps({"type": "ready"}))
            audio_frames_in = 0
            transcripts_out = 0

            async def to_stt():
                nonlocal omni_bearer, omni_user_id, omni_agent_id, audio_frames_in
                async for message in client_ws:
                    if not isinstance(message, str):
                        continue
                    try:
                        data = json.loads(message)
                    except json.JSONDecodeError:
                        continue

                    msg_type = data.get("type", "")

                    if msg_type == "audio":
                        audio_b64 = data.get("audio", "")
                        if not audio_b64:
                            continue
                        pcm_8k = base64.b64decode(audio_b64)
                        if not pcm_8k:
                            continue

                        audio_frames_in += 1
                        if LOG_AUDIO and audio_frames_in % 100 == 1:
                            print(f"[json-bridge] audio frame #{audio_frames_in} ({len(pcm_8k)} bytes)")

                        # Resample 8kHz -> 16kHz for STT
                        pcm_float = _pcm16_bytes_to_float32(pcm_8k)
                        pcm_16k = to_stt_resampler.run(pcm_float)
                        stt_bytes = _float32_to_pcm16_bytes(pcm_16k)
                        if stt_bytes:
                            audio_16k_b64 = base64.b64encode(stt_bytes).decode("ascii")
                            stt_payload = json.dumps({
                                "message_type": "input_audio_chunk",
                                "audio_base_64": audio_16k_b64,
                                "sample_rate": ELEVENLABS_STT_RATE,
                            })
                            await stt_ws.send(stt_payload)
                            if audio_frames_in <= 3:
                                print(f"[json-bridge] -> STT: {len(stt_bytes)} bytes resampled, b64 len={len(audio_16k_b64)}")

                    elif msg_type == "control":
                        new_bearer = str(data.get("omni_bearer") or "").strip()
                        new_user_id = str(data.get("omni_user_id") or "").strip()
                        new_agent_id = str(data.get("omni_agent_id") or "").strip()
                        if new_bearer:
                            omni_bearer = new_bearer
                        if new_user_id:
                            omni_user_id = new_user_id
                        if new_agent_id:
                            omni_agent_id = new_agent_id
                        print(f"[json-bridge] Auth updated: user={omni_user_id} agent={omni_agent_id}")

                    elif msg_type == "trigger_welcome":
                        print("[json-bridge] trigger_welcome received - sending greeting TTS")
                        welcome_text = "Hi! How can I assist you?"
                        await client_ws.send(json.dumps({
                            "type": "ai_reply",
                            "input_text": "",
                            "reply_text": welcome_text,
                        }))
                        await _tts_and_stream_back(client_ws, http_session, welcome_text, tts_resampler)

                    elif msg_type == "call_start":
                        print("[json-bridge] Call started")

                    elif msg_type == "call_end":
                        print("[json-bridge] Call ended by bridge")
                        break

            async def from_stt():
                nonlocal transcripts_out
                stt_msg_count = 0
                async for message in stt_ws:
                    if not isinstance(message, str):
                        print(f"[json-bridge] <- STT binary msg: {len(message)} bytes")
                        continue
                    try:
                        payload = json.loads(message)
                    except json.JSONDecodeError:
                        print(f"[json-bridge] <- STT non-json: {message[:200]}")
                        continue

                    stt_msg_count += 1
                    msg_type = str(payload.get("message_type") or "").lower()

                    # Log ALL messages from ElevenLabs for debugging
                    if stt_msg_count <= 20 or msg_type not in {"partial_transcript", "session_started"}:
                        print(f"[json-bridge] <- STT msg #{stt_msg_count} type={msg_type}: {json.dumps(payload)[:300]}")

                    if msg_type == "session_started":
                        print("[json-bridge] STT session started")
                        continue
                    if "error" in msg_type:
                        print(f"[json-bridge] STT error: {payload}")
                        await client_ws.send(json.dumps({
                            "type": "error",
                            "detail": f"STT error: {json.dumps(payload)}",
                        }))
                        continue

                    transcript, is_final = _extract_stt_transcript(payload)
                    if not transcript:
                        continue

                    if not is_final:
                        print(f"[json-bridge] STT partial: {transcript}")
                        continue

                    # Final transcript -> check greeting cache first, then API
                    print(f"[json-bridge] STT final: {transcript}")
                    await client_ws.send(json.dumps({
                        "type": "stt_final",
                        "text": transcript,
                    }))

                    # Check greeting cache for instant response
                    cached = _check_greeting_cache(transcript)
                    if cached:
                        ai_text = cached
                        print(f"[json-bridge] Greeting cache hit: {ai_text}")
                    else:
                        ai_text = await _call_api_query(
                            http_session, transcript,
                            bearer=omni_bearer,
                            user_id=omni_user_id,
                            agent_id=omni_agent_id,
                        )
                        print(f"[json-bridge] AI reply: {ai_text[:150]}")

                    transcripts_out += 1

                    await client_ws.send(json.dumps({
                        "type": "ai_reply",
                        "input_text": transcript,
                        "reply_text": ai_text,
                    }))

                    # TTS: only speak successful replies, not API errors
                    if not ai_text.startswith("API error"):
                        await _tts_and_stream_back(client_ws, http_session, ai_text, tts_resampler)

            tasks = [
                asyncio.create_task(to_stt()),
                asyncio.create_task(from_stt()),
            ]
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            for task in done:
                exc = task.exception()
                if exc:
                    print(f"[json-bridge] task error: {type(exc).__name__}: {exc}")
            print(f"[json-bridge] stats audio_in={audio_frames_in} transcripts={transcripts_out}")

    except websockets.exceptions.InvalidStatusCode as exc:
        status = getattr(exc, "status_code", "unknown")
        print(f"[json-bridge] STT handshake failed HTTP {status}")
        try:
            await client_ws.send(json.dumps({
                "type": "error",
                "detail": f"ElevenLabs handshake failed HTTP {status}. Check API key and STT permissions.",
            }))
        except Exception:
            pass
    except websockets.exceptions.ConnectionClosed:
        print("[json-bridge] Connection closed")
    except Exception as error:
        print(f"[json-bridge] Error: {error}")
        try:
            await client_ws.send(json.dumps({"type": "error", "detail": str(error)}))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Handler 3: OmniCortex voice pipeline (routes telephony through /ws/voice/)
# ---------------------------------------------------------------------------

OMNI_VOICE_WS_URL = str(os.getenv("OMNI_VOICE_WS_URL", "")).strip()
OMNI_VOICE_MODE = str(os.getenv("OMNI_VOICE_MODE", "lfm")).strip()
OMNI_VOICE_ENABLED = str(os.getenv("OMNI_VOICE_ENABLED", "false")).strip().lower() == "true"


async def bridge_call_omnicortex(client_ws):
    """Route telephony audio through OmniCortex /ws/voice/{agent_id}.

    Receives JSON messages from fast_ai_bridge.py (same format as bridge_call_json),
    forwards binary PCM to OmniCortex voice pipeline, relays responses back.
    """
    if not OMNI_VOICE_WS_URL:
        await client_ws.send(json.dumps({"type": "error", "detail": "OMNI_VOICE_WS_URL not configured"}))
        await client_ws.close(code=1011, reason="OMNI_VOICE_WS_URL not set")
        return

    # Auth context (can be updated by control messages from bridge)
    omni_bearer = API_BEARER_TOKEN
    omni_user_id = "voice_user"
    omni_agent_id = API_AGENT_ID

    # Build OmniCortex WS URL with mode and auth
    voice_url = OMNI_VOICE_WS_URL.rstrip("/")
    if "?" in voice_url:
        voice_url += f"&mode={OMNI_VOICE_MODE}&token={omni_bearer}"
    else:
        voice_url += f"?mode={OMNI_VOICE_MODE}&token={omni_bearer}"
    if omni_user_id:
        voice_url += f"&x_user_id={omni_user_id}"

    print(f"[omnicortex] Connecting to {voice_url}")

    try:
        async with websockets.connect(
            voice_url,
            open_timeout=15,
            ping_interval=20,
            ping_timeout=20,
            max_size=8 * 1024 * 1024,
        ) as omni_ws:
            print("[omnicortex] Connected to OmniCortex voice pipeline")
            await client_ws.send(json.dumps({"type": "ready"}))

            async def bridge_to_omni():
                """Forward audio from fast_ai_bridge -> OmniCortex as binary PCM."""
                nonlocal omni_bearer, omni_user_id, omni_agent_id
                async for message in client_ws:
                    if not isinstance(message, str):
                        continue
                    try:
                        data = json.loads(message)
                    except json.JSONDecodeError:
                        continue

                    msg_type = data.get("type", "")

                    if msg_type == "audio":
                        audio_b64 = data.get("audio", "")
                        if not audio_b64:
                            continue
                        pcm_bytes = base64.b64decode(audio_b64)
                        if pcm_bytes:
                            await omni_ws.send(pcm_bytes)

                    elif msg_type == "control":
                        new_bearer = str(data.get("omni_bearer") or "").strip()
                        new_user_id = str(data.get("omni_user_id") or "").strip()
                        new_agent_id = str(data.get("omni_agent_id") or "").strip()
                        if new_bearer:
                            omni_bearer = new_bearer
                        if new_user_id:
                            omni_user_id = new_user_id
                        if new_agent_id:
                            omni_agent_id = new_agent_id
                        print(f"[omnicortex] Auth updated: user={omni_user_id} agent={omni_agent_id}")

                    elif msg_type == "trigger_welcome":
                        print("[omnicortex] trigger_welcome (handled by voice pipeline)")

                    elif msg_type == "call_start":
                        print("[omnicortex] Call started")

                    elif msg_type == "call_end":
                        print("[omnicortex] Call ended by bridge")
                        # Send stop control to OmniCortex
                        await omni_ws.send(json.dumps({"type": "control", "action": "stop"}))
                        break

            async def omni_to_bridge():
                """Forward OmniCortex responses -> fast_ai_bridge."""
                async for message in omni_ws:
                    if isinstance(message, bytes):
                        # Binary PCM audio from voice pipeline -> base64 for bridge
                        if message:
                            audio_b64 = base64.b64encode(message).decode("ascii")
                            await client_ws.send(json.dumps({
                                "type": "tts_audio",
                                "audio": audio_b64,
                            }))
                            # Send tts_done after each audio chunk
                            # (voice pipeline sends complete utterance audio at once)
                            await client_ws.send(json.dumps({"type": "tts_done"}))

                    elif isinstance(message, str):
                        # JSON messages from voice pipeline
                        try:
                            data = json.loads(message)
                        except json.JSONDecodeError:
                            continue

                        omni_type = data.get("type", "")

                        if omni_type == "transcript":
                            if data.get("final"):
                                await client_ws.send(json.dumps({
                                    "type": "stt_final",
                                    "text": data.get("text", ""),
                                }))
                                print(f"[omnicortex] STT: {data.get('text', '')[:120]}")

                        elif omni_type == "answer":
                            await client_ws.send(json.dumps({
                                "type": "ai_reply",
                                "input_text": "",
                                "reply_text": data.get("text", ""),
                            }))
                            print(f"[omnicortex] AI: {data.get('text', '')[:120]}")

                        elif omni_type == "error":
                            await client_ws.send(json.dumps({
                                "type": "error",
                                "detail": data.get("message", "Voice pipeline error"),
                            }))

                        elif omni_type == "status":
                            print(f"[omnicortex] Status: {data.get('status', '')}")

            tasks = [
                asyncio.create_task(bridge_to_omni()),
                asyncio.create_task(omni_to_bridge()),
            ]
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            for task in done:
                exc = task.exception()
                if exc:
                    print(f"[omnicortex] task error: {type(exc).__name__}: {exc}")
            print("[omnicortex] Session ended")

    except websockets.exceptions.ConnectionClosed:
        print("[omnicortex] Connection closed")
    except Exception as error:
        print(f"[omnicortex] Error: {error}")
        try:
            await client_ws.send(json.dumps({"type": "error", "detail": str(error)}))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Dispatcher: route by WebSocket path
# ---------------------------------------------------------------------------

async def bridge_call(client_ws):
    path = getattr(client_ws, "path", None) or "/"
    # Also check request.path for newer websockets versions
    if path == "/" and hasattr(client_ws, "request"):
        path = getattr(client_ws.request, "path", "/") or "/"

    if path.startswith("/omnicortex"):
        print(f"[dispatch] OmniCortex voice pipeline on path={path}")
        await bridge_call_omnicortex(client_ws)
    elif path.startswith("/bridge"):
        print(f"[dispatch] JSON bridge protocol on path={path}")
        await bridge_call_json(client_ws)
    else:
        print(f"[dispatch] Binary gateway protocol on path={path}")
        await bridge_call_elevenlabs(client_ws)


async def main():
    print(f"[startup] bridge host={HOST} port={PORT}")
    print(f"[startup] paths: / (binary gateway), /bridge (JSON FreeSWITCH), /omnicortex (voice pipeline)")
    print(f"[startup] gateway_rate={GATEWAY_RATE} stt_rate={ELEVENLABS_STT_RATE}")
    print(f"[startup] elevenlabs_language={ELEVENLABS_STT_LANGUAGE}")
    print(f"[startup] binary_path: ai_vllm_reply={AI_USE_VLLM_REPLY} model={VLLM_MODEL}")
    print(f"[startup] bridge_path: api_query={API_QUERY_URL} agent={API_AGENT_ID}")
    print(f"[startup] omnicortex: url={OMNI_VOICE_WS_URL or '(not set)'} mode={OMNI_VOICE_MODE}")
    print(f"[startup] tts: voice={ELEVENLABS_VOICE_ID} model={ELEVENLABS_TTS_MODEL_ID}")
    async with websockets.serve(bridge_call, HOST, PORT, process_request=process_request):
        print("[startup] AI bridge live")
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main())
