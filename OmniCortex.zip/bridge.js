const WebSocket = require('ws');

// --- CONFIGURATION ---
const LOCAL_PORT = 8001;
const RUNPOD_URL = process.env.RUNPOD_URL || 'wss://zjhvuamwuevz8x-9001.proxy.runpod.net';
const RUNPOD_API_KEY = process.env.RUNPOD_API_KEY || 'b6f3b11e-64a5-49c7-9a90-54dd5a4cd482';
const TEXT_PROMPT = process.env.TEXT_PROMPT || 'You are a helpful voice assistant. Be concise and friendly.';

const server = new WebSocket.Server({ port: LOCAL_PORT });

console.log(`Bridge started on ws://localhost:${LOCAL_PORT}`);
console.log(`Upstream: ${RUNPOD_URL}`);
console.log(`Auth: ${RUNPOD_API_KEY ? 'enabled' : 'disabled'}`);

server.on('connection', (fsWs, req) => {
    const uuid = req.url.split('/').pop();
    console.log(`[call] Connected! UUID: ${uuid}`);

    const headers = {};
    if (RUNPOD_API_KEY) {
        headers['x-api-key'] = RUNPOD_API_KEY;
    }

    // Add text prompt as query parameter
    const sep = RUNPOD_URL.includes('?') ? '&' : '?';
    const moshiFullUrl = `${RUNPOD_URL}${sep}text_prompt=${encodeURIComponent(TEXT_PROMPT)}`;

    const moshiWs = new WebSocket(moshiFullUrl, { headers });

    let txCount = 0, rxCount = 0;

    // FreeSWITCH -> RunPod (Raw PCM, no kind bytes)
    fsWs.on('message', (data) => {
        if (!Buffer.isBuffer(data) || data.length === 0) return;
        if (moshiWs.readyState === WebSocket.OPEN) {
            moshiWs.send(data);
            txCount++;
            if (txCount <= 3 || txCount % 500 === 0) {
                console.log(`[>] #${txCount} FS->RunPod ${data.length}B`);
            }
        }
    });

    // RunPod -> FreeSWITCH (Raw PCM back from ai_server.py)
    moshiWs.on('message', (data) => {
        if (!Buffer.isBuffer(data) || data.length === 0) return;
        if (fsWs.readyState === WebSocket.OPEN) {
            fsWs.send(data);
            rxCount++;
            if (rxCount <= 5 || rxCount % 100 === 0) {
                console.log(`[<] #${rxCount} RunPod->FS ${data.length}B`);
            }
        }
    });

    moshiWs.on('open', () => {
        console.log('[moshi] Connected to RunPod (Opus handled server-side)');
    });

    moshiWs.on('error', (err) => console.error('[moshi] Error:', err.message));
    fsWs.on('error', (err) => console.error('[fs] Error:', err.message));

    moshiWs.on('close', (code) => {
        console.log(`[moshi] Closed (code=${code}) | tx=${txCount} rx=${rxCount}`);
        if (fsWs.readyState === WebSocket.OPEN) fsWs.close();
    });

    fsWs.on('close', () => {
        console.log(`[call] Ended UUID: ${uuid} | sent=${txCount} recv=${rxCount}`);
        if (moshiWs.readyState === WebSocket.OPEN) moshiWs.close();
    });
});
