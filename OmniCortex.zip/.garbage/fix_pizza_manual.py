
from core.database import SessionLocal, Agent, init_db

init_db()
db = SessionLocal()

# Pizza Agent ID
agent_id = "08699428-93c7-450d-976a-013c0724a7d2"

image_urls = [
    "https://images.unsplash.com/photo-1514933651103-005eec06c04b",
    "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca",
    "https://images.unsplash.com/photo-1556910103-1c02745aae4d",
    "https://images.unsplash.com/photo-1573144176728-18244dd86158"
]

try:
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if agent:
        print(f"Update agent {agent.name} (ID: {agent.id})")
        # Ensure list is stored
        current = agent.image_urls or []
        updated = list(set(current + image_urls))
        # Override to force update
        agent.image_urls = updated 
        db.commit()
        print(f"✅ Updated Pizza Agent image_urls. Count: {len(updated)}")
        print(f"New URLs: {updated}")
    else:
        print("❌ Pizza Agent not found")
finally:
    db.close()
