"""Tool-calling package scaffold."""

