declare module "opus-recorder";
